# 📖 System Usage Guide

## 🏠 Dashboard Overview

The dashboard provides a complete overview of your library system with quick access to all major functions.

### Dashboard Components

#### Statistics Cards
- **Total Members**: Count of all registered members
- **Total Books**: Count of all books in the system
- **Borrowed Books**: Count of currently borrowed books
- **Available Books**: Count of books available for borrowing

#### Quick Actions
- **Add Member**: Quick access to add new members
- **Add Book**: Quick access to add new books
- **Borrow Book**: Quick access to borrow books
- **View All Borrowed**: Navigate to borrowed books page

#### Recent Activity
- **Recent Borrowed Books**: Latest 5 borrowing records
- **Member and Book Details**: Shows who borrowed what and when

#### System Information
- **Database Type**: Current database (MySQL/SQLite)
- **Current Time**: Server time
- **PHP Version**: Current PHP version
- **Server Info**: Web server information

## 👥 Managing Members

### Adding a New Member

#### Method 1: From Dashboard
1. Click **"Add Member"** button in Quick Actions section
2. Modal form opens
3. Fill in the required fields:
   - **Name**: Full name of the member
   - **Course**: Student's course/program (e.g., BSIT, BSCS)
   - **Email**: Valid email address
4. Click **"Add Member"** button
5. Member appears in the members list immediately

#### Method 2: From Members Page
1. Navigate to **Members** page
2. Click **"Add Member"** button at the top
3. Follow same form filling process

#### Form Validation
- **Name**: Required, minimum 2 characters
- **Course**: Required, minimum 2 characters
- **Email**: Required, must be valid email format, must be unique

### Editing Member Information

1. **Locate Member**: Find the member in the members table
2. **Click Edit**: Click the pencil icon (✏️) in the Actions column
3. **Update Data**: Modal opens with pre-filled current data
4. **Make Changes**: Modify name, course, or email
5. **Save Changes**: Click **"Update Member"** button
6. **Verify**: Changes are reflected immediately in the table

### Viewing Member Details

1. **Click View**: Click the eye icon (👁️) in the Actions column
2. **View Information**: Modal shows complete member details:
   - Basic information (name, course, email)
   - Creation date
   - Borrowing history (if any)
3. **Close Modal**: Click **"Close"** button or click outside modal

### Deleting Members

#### Important Notes
- **Members with borrowed books CANNOT be deleted**
- Only members with no borrowing history can be removed
- This prevents data integrity issues

#### Delete Process
1. **Check Eligibility**: Ensure member has no borrowed books
2. **Click Delete**: Click the trash icon (🗑️) in the Actions column
3. **Confirmation**: Confirmation dialog appears
4. **Confirm Deletion**: Click **"Yes, Delete"** to proceed
5. **Verification**: Member is removed from the system

## 📚 Managing Books

### Adding a New Book

#### Method 1: From Dashboard
1. Click **"Add Book"** button in Quick Actions section
2. Modal form opens
3. Fill in the required fields:
   - **Title**: Book title
   - **Author**: Book author
4. Click **"Add Book"** button
5. Book appears in the books list with "Available" status

#### Method 2: From Books Page
1. Navigate to **Books** page
2. Click **"Add Book"** button at the top
3. Follow same form filling process

#### Form Validation
- **Title**: Required, minimum 2 characters
- **Author**: Required, minimum 2 characters

### Book Status Indicators

#### Available Books (🟢)
- **Status**: Shows "Available" in green
- **Action**: Can be borrowed by members
- **Borrow Button**: Available for clicking

#### Borrowed Books (🔴)
- **Status**: Shows "Borrowed" in red
- **Action**: Cannot be borrowed (already borrowed)
- **Borrow Button**: Disabled or shows "Currently Borrowed"

### Editing Book Information

1. **Locate Book**: Find the book in the books table
2. **Click Edit**: Click the pencil icon (✏️) in the Actions column
3. **Update Data**: Modal opens with pre-filled current data
4. **Make Changes**: Modify title or author
5. **Save Changes**: Click **"Update Book"** button
6. **Verify**: Changes are reflected immediately in the table

### Deleting Books

#### Important Notes
- **Borrowed books CANNOT be deleted**
- Only available books can be removed
- This prevents data integrity issues

#### Delete Process
1. **Check Eligibility**: Ensure book is available (not borrowed)
2. **Click Delete**: Click the trash icon (🗑️) in the Actions column
3. **Confirmation**: Confirmation dialog appears
4. **Confirm Deletion**: Click **"Yes, Delete"** to proceed
5. **Verification**: Book is removed from the system

## 🔄 Managing Borrowed Books

### Borrowing a Book

#### Method 1: From Dashboard
1. Click **"Borrow Book"** button in Quick Actions section
2. Modal form opens
3. Fill in the required fields:
   - **Select Member**: Choose from existing members dropdown
   - **Select Book**: Choose from available books dropdown
   - **Borrow Date**: Automatically set to current date/time
4. Click **"Borrow Book"** button
5. Book status changes to "Borrowed" immediately

#### Method 2: From Books Page
1. Navigate to **Books** page
2. Find an available book
3. Click **"Borrow"** button on the book row
4. Follow same form filling process

#### Form Validation
- **Member**: Must select an existing member
- **Book**: Must select an available book
- **Date**: Automatically set, cannot be modified

### Viewing All Borrowed Books

1. **Navigate**: Go to **Borrowed Books** page
2. **View Table**: Table shows all borrowing records with:
   - **Member**: Name and course
   - **Book**: Title and author
   - **Borrow Date**: When the book was borrowed
   - **Duration**: Days since borrowed
   - **Actions**: Edit or return options

### Searching Borrowed Books

#### Search Bar
- **Location**: Top of the borrowed books table
- **Functionality**: Real-time search as you type
- **Search Fields**: Member name, book title, or author
- **Results**: Updates automatically as you type

#### Filter Options
- **Recent**: Books borrowed within 7 days
- **Medium**: Books borrowed 8-30 days ago
- **Old**: Books borrowed more than 30 days ago

#### Advanced Search
- **Combined Search**: Search across multiple fields
- **Case Insensitive**: Search works regardless of case
- **Partial Match**: Find partial names or titles

### Returning Books

1. **Locate Record**: Find the borrowed book record
2. **Click Return**: Click the trash icon (🗑️) in the Actions column
3. **Confirmation**: Confirmation dialog appears
4. **Confirm Return**: Click **"Yes, Return"** to proceed
5. **Status Update**: Book status changes to "Available"
6. **Record Removal**: Borrowing record is removed from the list

## 🔍 Advanced Features

### Search Functionality

#### Global Search
- **Scope**: Searches across all tables
- **Speed**: Real-time results
- **Accuracy**: Finds exact and partial matches

#### Table-Specific Search
- **DataTables**: Enhanced search in each table
- **Column Filtering**: Filter by specific columns
- **Advanced Options**: Export, copy, print functionality

#### Real-time Filtering
- **Instant Results**: No need to press Enter
- **Live Updates**: Results change as you type
- **Performance**: Optimized for fast response

### Data Export

#### Copy to Clipboard
1. **Select Data**: Choose data to copy
2. **Click Copy**: Use copy button in DataTables
3. **Paste**: Data is copied to clipboard

#### CSV Export
1. **Click Export**: Use CSV export button
2. **Download**: File downloads automatically
3. **Open**: Use Excel or any CSV viewer

#### Print View
1. **Click Print**: Use print button
2. **Print Preview**: See formatted version
3. **Print**: Send to printer

### Responsive Design

#### Mobile Friendly
- **Responsive Tables**: Tables adapt to screen size
- **Touch Optimized**: Easy to use on mobile devices
- **Collapsible Navigation**: Mobile-friendly menu

#### Desktop Optimized
- **Full Features**: All functionality available
- **Large Tables**: Full data display
- **Advanced Controls**: All search and filter options

## 📊 Understanding the Data

### Member Information

#### Data Fields
- **ID**: Unique identifier (auto-generated)
- **Name**: Full name of the member
- **Course**: Academic program or course
- **Email**: Contact email address
- **Created**: When the member was added to the system

#### Data Validation
- **Email Format**: Must be valid email address
- **Uniqueness**: Email must be unique in the system
- **Required Fields**: All fields are mandatory

### Book Information

#### Data Fields
- **ID**: Unique identifier (auto-generated)
- **Title**: Name of the book
- **Author**: Book author
- **Status**: Available or Borrowed
- **Created**: When the book was added to the system

#### Status Management
- **Automatic Updates**: Status changes automatically
- **Real-time**: Updates happen immediately
- **Consistent**: Status is always accurate

### Borrowing Records

#### Data Fields
- **ID**: Unique borrowing record identifier
- **Member**: Who borrowed the book
- **Book**: Which book was borrowed
- **Borrow Date**: When the book was borrowed
- **Duration**: How long the book has been borrowed

#### Relationship Management
- **Foreign Keys**: Maintains data integrity
- **Cascade Deletion**: Handles related records properly
- **Validation**: Prevents invalid relationships

## 🚨 Important Notes

### Data Integrity

#### Foreign Key Constraints
- **Prevents Orphaned Records**: Cannot delete members/books with active borrowings
- **Cascade Deletion**: Related records are handled automatically
- **Data Consistency**: Ensures data remains valid

#### Validation Rules
- **Input Validation**: All forms include validation
- **Server-side Checks**: Additional validation on server
- **Error Handling**: Clear error messages for users

### Security Features

#### SQL Injection Protection
- **Prepared Statements**: All database queries use prepared statements
- **Parameter Binding**: User input is safely bound to queries
- **Input Sanitization**: All inputs are cleaned before processing

#### XSS Prevention
- **Output Escaping**: All output is properly escaped
- **HTML Special Characters**: Prevents malicious scripts
- **Safe Display**: Content is displayed safely

#### Input Validation
- **Client-side**: Immediate feedback to users
- **Server-side**: Final validation before processing
- **Format Checking**: Ensures data meets requirements

### Performance Tips

#### Database Optimization
- **Proper Indexing**: Indexes on foreign keys and search fields
- **Efficient Queries**: Optimized JOIN operations
- **Minimal Calls**: Reduce database queries where possible

#### User Experience
- **Real-time Search**: Instant results for better UX
- **Responsive Design**: Works on all devices
- **Fast Loading**: Optimized for quick response times

## 📋 Quick Reference

### Keyboard Shortcuts
- **Tab**: Navigate between form fields
- **Enter**: Submit forms
- **Escape**: Close modals
- **Ctrl+F**: Search in tables

### Common Actions
- **Add**: Use "Add" buttons for new records
- **Edit**: Click pencil icon to modify records
- **View**: Click eye icon to see details
- **Delete**: Click trash icon to remove records

### Navigation
- **Dashboard**: Main overview page
- **Members**: Manage library members
- **Books**: Manage library books
- **Borrowed**: View borrowing records

---

**Previous: [DATABASE.md](DATABASE.md) - Database Configuration & Switching**  
**Next: [SETUP.md](SETUP.md) - Installation & Setup Guide**
