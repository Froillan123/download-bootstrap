# Database Directory

This directory contains the database files for the Library System.

## Files

- `library.db` - SQLite database file (created automatically when using SQLite)
- `README.md` - This file

## Database Setup

### SQLite (Default)
- The SQLite database file will be created automatically when you first run the application
- No additional setup required
- Database file: `library.db`

### MySQL (XAMPP)
1. Start XAMPP (Apache + MySQL)
2. Open phpMyAdmin: http://localhost/phpmyadmin
3. Create a new database named `library_system`
4. The tables will be created automatically when you first run the application

## Configuration

Edit `config/database.php` to switch between database types:

```php
// For MySQL (XAMPP)
define('DB_TYPE', 'mysql');

// For SQLite
define('DB_TYPE', 'sqlite');
```

## Tables

The following tables will be created automatically:

1. **members** - Library members information
2. **books** - Book catalog
3. **borrowed_books** - Book borrowing records (join table)

## Backup

- **SQLite**: Copy the `library.db` file
- **MySQL**: Use phpMyAdmin export function
