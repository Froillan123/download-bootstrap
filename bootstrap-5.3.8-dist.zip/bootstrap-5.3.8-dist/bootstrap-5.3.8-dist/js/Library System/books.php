<?php
$pageTitle = "Books Management";
require_once 'includes/header.php';
require_once 'config/functions.php';

$books = getAllBooks();
$availableBooks = getAvailableBooks();
$borrowedBooks = array_filter($books, function($book) { return bookIsBorrowed($book['id']); });
?>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0">
                <i class="bi bi-book"></i> Books Management
            </h1>
            <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#addBookModal">
                <i class="bi bi-book-plus"></i> Add New Book
            </button>
        </div>
    </div>
</div>

<!-- Books Statistics -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card text-center">
            <div class="card-body">
                <h3 class="text-primary"><?php echo count($books); ?></h3>
                <p class="text-muted mb-0">Total Books</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-center">
            <div class="card-body">
                <h3 class="text-success"><?php echo count($availableBooks); ?></h3>
                <p class="text-muted mb-0">Available</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-center">
            <div class="card-body">
                <h3 class="text-warning"><?php echo count($borrowedBooks); ?></h3>
                <p class="text-muted mb-0">Borrowed</p>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card text-center">
            <div class="card-body">
                <h3 class="text-info"><?php echo count(array_unique(array_column($books, 'author'))); ?></h3>
                <p class="text-muted mb-0">Authors</p>
            </div>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="bi bi-list-ul"></i> All Books
        </h5>
    </div>
    <div class="card-body">
        <?php if (empty($books)): ?>
            <div class="text-center py-5">
                <i class="bi bi-book display-1 text-muted"></i>
                <h4 class="text-muted mt-3">No Books Found</h4>
                <p class="text-muted">Start by adding your first book using the button above.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover datatable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Author</th>
                            <th>Status</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($books as $book): ?>
                            <tr>
                                <td>
                                    <span class="badge bg-secondary"><?php echo $book['id']; ?></span>
                                </td>
                                <td>
                                    <strong><?php echo htmlspecialchars($book['title']); ?></strong>
                                </td>
                                <td>
                                    <span class="badge bg-info"><?php echo htmlspecialchars($book['author']); ?></span>
                                </td>
                                <td>
                                    <?php if (bookIsBorrowed($book['id'])): ?>
                                        <span class="badge bg-warning">
                                            <i class="bi bi-arrow-left-right"></i> Borrowed
                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-success">
                                            <i class="bi bi-check-circle"></i> Available
                                        </span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <small class="text-muted">
                                        <?php echo formatDate($book['created_at']); ?>
                                    </small>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <button type="button" class="btn btn-sm btn-outline-info" 
                                                onclick="viewBook(<?php echo $book['id']; ?>)">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-outline-primary" 
                                                onclick="editBook(<?php echo $book['id']; ?>, '<?php echo htmlspecialchars($book['title']); ?>', '<?php echo htmlspecialchars($book['author']); ?>')">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <?php if (!bookIsBorrowed($book['id'])): ?>
                                            <button type="button" class="btn btn-sm btn-outline-danger" 
                                                    onclick="showDeleteConfirm('book', <?php echo $book['id']; ?>, '<?php echo htmlspecialchars($book['title']); ?>')">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        <?php else: ?>
                                            <button type="button" class="btn btn-sm btn-outline-secondary" disabled 
                                                    title="Cannot delete book that is currently borrowed">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Additional Information -->
<div class="row mt-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="bi bi-check-circle"></i> Available Books
                </h6>
            </div>
            <div class="card-body">
                <?php if (empty($availableBooks)): ?>
                    <p class="text-muted">All books are currently borrowed.</p>
                <?php else: ?>
                    <div class="list-group list-group-flush">
                        <?php foreach (array_slice($availableBooks, 0, 5) as $book): ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <strong><?php echo htmlspecialchars($book['title']); ?></strong><br>
                                    <small class="text-muted">by <?php echo htmlspecialchars($book['author']); ?></small>
                                </div>
                                <span class="badge bg-success">Available</span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    <?php if (count($availableBooks) > 5): ?>
                        <div class="text-center mt-2">
                            <small class="text-muted">And <?php echo count($availableBooks) - 5; ?> more...</small>
                        </div>
                    <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="bi bi-arrow-left-right"></i> Recently Borrowed Books
                </h6>
            </div>
            <div class="card-body">
                <?php
                $recentBorrowed = array_slice(getAllBorrowedBooks(), 0, 5);
                if (empty($recentBorrowed)) {
                    echo '<p class="text-muted">No books have been borrowed yet.</p>';
                } else {
                    foreach ($recentBorrowed as $borrowed) {
                        echo '<div class="d-flex align-items-center mb-2">';
                        echo '<div class="flex-shrink-0">';
                        echo '<i class="bi bi-book text-warning"></i>';
                        echo '</div>';
                        echo '<div class="flex-grow-1 ms-3">';
                        echo '<strong>' . htmlspecialchars($borrowed['title']) . '</strong><br>';
                        echo '<small class="text-muted">Borrowed by ' . htmlspecialchars($borrowed['member_name']) . '</small>';
                        echo '</div>';
                        echo '<small class="text-muted">' . formatDate($borrowed['borrow_date']) . '</small>';
                        echo '</div>';
                    }
                }
                ?>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/modals.php'; ?>
<?php require_once 'includes/footer.php'; ?>
