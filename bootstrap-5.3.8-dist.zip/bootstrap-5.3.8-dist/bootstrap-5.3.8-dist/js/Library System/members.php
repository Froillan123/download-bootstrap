<?php
$pageTitle = "Members Management";
require_once 'includes/header.php';
require_once 'config/functions.php';

$members = getAllMembers();
?>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0">
                <i class="bi bi-people"></i> Members Management
            </h1>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addMemberModal">
                <i class="bi bi-person-plus"></i> Add New Member
            </button>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="bi bi-list-ul"></i> All Members
        </h5>
    </div>
    <div class="card-body">
        <?php if (empty($members)): ?>
            <div class="text-center py-5">
                <i class="bi bi-people display-1 text-muted"></i>
                <h4 class="text-muted mt-3">No Members Found</h4>
                <p class="text-muted">Start by adding your first member using the button above.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover datatable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Course</th>
                            <th>Email</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($members as $member): ?>
                            <tr>
                                <td>
                                    <span class="badge bg-secondary"><?php echo $member['id']; ?></span>
                                </td>
                                <td>
                                    <strong><?php echo htmlspecialchars($member['name']); ?></strong>
                                </td>
                                <td>
                                    <span class="badge bg-info"><?php echo htmlspecialchars($member['course']); ?></span>
                                </td>
                                <td>
                                    <a href="mailto:<?php echo htmlspecialchars($member['email']); ?>" class="text-decoration-none">
                                        <?php echo htmlspecialchars($member['email']); ?>
                                    </a>
                                </td>
                                <td>
                                    <small class="text-muted">
                                        <?php echo formatDate($member['created_at']); ?>
                                    </small>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <button type="button" class="btn btn-sm btn-outline-info" 
                                                onclick="viewMember(<?php echo $member['id']; ?>)">
                                            <i class="bi bi-eye"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-outline-primary" 
                                                onclick="editMember(<?php echo $member['id']; ?>, '<?php echo htmlspecialchars($member['name']); ?>', '<?php echo htmlspecialchars($member['course']); ?>', '<?php echo htmlspecialchars($member['email']); ?>')">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <?php if (!memberHasBorrowedBooks($member['id'])): ?>
                                            <button type="button" class="btn btn-sm btn-outline-danger" 
                                                    onclick="showDeleteConfirm('member', <?php echo $member['id']; ?>, '<?php echo htmlspecialchars($member['name']); ?>')">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        <?php else: ?>
                                            <button type="button" class="btn btn-sm btn-outline-secondary" disabled 
                                                    title="Cannot delete member with borrowed books">
                                                <i class="bi bi-trash"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Member Statistics -->
<div class="row mt-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="bi bi-graph-up"></i> Member Statistics
                </h6>
            </div>
            <div class="card-body">
                <div class="row text-center">
                    <div class="col-6">
                        <h4 class="text-primary"><?php echo count($members); ?></h4>
                        <small class="text-muted">Total Members</small>
                    </div>
                    <div class="col-6">
                        <h4 class="text-success"><?php echo count(array_filter($members, function($m) { return memberHasBorrowedBooks($m['id']); })); ?></h4>
                        <small class="text-muted">Active Borrowers</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="bi bi-clock-history"></i> Recent Members
                </h6>
            </div>
            <div class="card-body">
                <?php
                $recentMembers = array_slice($members, 0, 3);
                foreach ($recentMembers as $member) {
                    echo '<div class="d-flex align-items-center mb-2">';
                    echo '<div class="flex-shrink-0">';
                    echo '<i class="bi bi-person-circle text-primary"></i>';
                    echo '</div>';
                    echo '<div class="flex-grow-1 ms-3">';
                    echo '<strong>' . htmlspecialchars($member['name']) . '</strong><br>';
                    echo '<small class="text-muted">' . htmlspecialchars($member['course']) . '</small>';
                    echo '</div>';
                    echo '</div>';
                }
                ?>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/modals.php'; ?>
<?php require_once 'includes/footer.php'; ?>
