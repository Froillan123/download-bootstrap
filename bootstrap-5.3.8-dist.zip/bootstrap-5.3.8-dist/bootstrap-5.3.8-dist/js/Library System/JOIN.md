# 🔗 JOIN Operations & Complex Queries

## 📚 Understanding JOINs

JOIN operations combine data from multiple tables based on related columns. In our Library System, we use JOINs to connect members, books, and borrowing records.

## 🔗 Basic JOIN Types

### INNER JOIN
Returns only records that have matching values in both tables.

```sql
-- Basic JOIN for Borrowed Books
SELECT bb.id, m.name, m.course, b.title, b.author, bb.borrow_date 
FROM borrowed_books bb
JOIN members m ON bb.member_id = m.id
JOIN books b ON bb.book_id = b.id
ORDER BY bb.borrow_date DESC;
```

**Result**: Shows only books that are currently borrowed.

### LEFT JOIN
Returns all records from the left table and matching records from the right table.

```sql
-- Show All Books with Borrowing Status
SELECT b.id, b.title, b.author, 
       CASE WHEN bb.id IS NOT NULL THEN 'Borrowed' ELSE 'Available' END as status,
       m.name as borrowed_by, bb.borrow_date
FROM books b
LEFT JOIN borrowed_books bb ON b.id = bb.book_id
LEFT JOIN members m ON bb.member_id = m.id
ORDER BY b.title;
```

**Result**: Shows all books (borrowed and available) with borrowing information.

### RIGHT JOIN
Returns all records from the right table and matching records from the left table.

```sql
-- Show All Members with Their Borrowing History
SELECT m.id, m.name, m.course, b.title, bb.borrow_date
FROM borrowed_books bb
RIGHT JOIN members m ON bb.member_id = m.id
LEFT JOIN books b ON bb.book_id = b.id
ORDER BY m.name;
```

**Result**: Shows all members (even those who never borrowed books).

## 🎯 Practical JOIN Examples

### 1. Dashboard Statistics
```sql
-- Count with JOIN for Statistics
SELECT 
    COUNT(DISTINCT m.id) as total_members,
    COUNT(DISTINCT b.id) as total_books,
    COUNT(bb.id) as borrowed_books,
    COUNT(DISTINCT b.id) - COUNT(bb.id) as available_books
FROM members m
CROSS JOIN books b
LEFT JOIN borrowed_books bb ON b.id = bb.book_id;
```

**What it does**: Counts total members, books, borrowed books, and calculates available books.

### 2. Search Across Multiple Tables
```sql
-- Search by Member Name, Book Title, or Author
SELECT bb.id, m.name, m.course, b.title, b.author, bb.borrow_date
FROM borrowed_books bb
JOIN members m ON bb.member_id = m.id
JOIN books b ON bb.book_id = b.id
WHERE m.name LIKE '%search_term%' 
   OR b.title LIKE '%search_term%' 
   OR b.author LIKE '%search_term%'
ORDER BY bb.borrow_date DESC;
```

**What it does**: Searches borrowed books by member name, book title, or author.

### 3. Date-Based Filtering
```sql
-- JOIN with Date Filtering
SELECT bb.id, m.name, m.course, b.title, b.author, bb.borrow_date,
       DATEDIFF(NOW(), bb.borrow_date) as days_borrowed
FROM borrowed_books bb
JOIN members m ON bb.member_id = m.id
JOIN books b ON bb.book_id = b.id
WHERE bb.borrow_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
ORDER BY bb.borrow_date DESC;
```

**What it does**: Shows books borrowed in the last 30 days with days borrowed calculation.

### 4. Member Borrowing History
```sql
-- Complete Member Borrowing History
SELECT m.name, m.course, m.email,
       b.title, b.author, bb.borrow_date,
       DATEDIFF(NOW(), bb.borrow_date) as days_borrowed
FROM members m
LEFT JOIN borrowed_books bb ON m.id = bb.member_id
LEFT JOIN books b ON bb.book_id = b.id
WHERE m.id = ?  -- Replace ? with member ID
ORDER BY bb.borrow_date DESC;
```

**What it does**: Shows complete borrowing history for a specific member.

### 5. Book Availability Status
```sql
-- All Books with Current Status
SELECT b.id, b.title, b.author,
       CASE 
           WHEN bb.id IS NOT NULL THEN 'Borrowed'
           ELSE 'Available'
       END as status,
       m.name as borrowed_by,
       bb.borrow_date,
       CASE 
           WHEN bb.id IS NOT NULL THEN DATEDIFF(NOW(), bb.borrow_date)
           ELSE NULL
       END as days_borrowed
FROM books b
LEFT JOIN borrowed_books bb ON b.id = bb.book_id
LEFT JOIN members m ON bb.member_id = m.id
ORDER BY b.title;
```

**What it does**: Shows all books with their current status and borrowing information.

## 🔍 Advanced JOIN Patterns

### 1. Self-JOIN for Related Books
```sql
-- Find Books by Same Author
SELECT b1.title as book1, b2.title as book2, b1.author
FROM books b1
JOIN books b2 ON b1.author = b2.author
WHERE b1.id < b2.id
ORDER BY b1.author, b1.title;
```

**What it does**: Finds pairs of books by the same author.

### 2. Multiple JOINs with Aggregation
```sql
-- Member Borrowing Statistics
SELECT m.name, m.course,
       COUNT(bb.id) as total_borrowed,
       COUNT(DISTINCT b.author) as unique_authors,
       MAX(bb.borrow_date) as last_borrowed
FROM members m
LEFT JOIN borrowed_books bb ON m.id = bb.member_id
LEFT JOIN books b ON bb.book_id = b.id
GROUP BY m.id, m.name, m.course
ORDER BY total_borrowed DESC;
```

**What it does**: Shows borrowing statistics for each member.

### 3. Conditional JOINs
```sql
-- Recent vs Old Borrowings
SELECT 
    CASE 
        WHEN DATEDIFF(NOW(), bb.borrow_date) <= 7 THEN 'Recent'
        WHEN DATEDIFF(NOW(), bb.borrow_date) <= 30 THEN 'Medium'
        ELSE 'Old'
    END as borrowing_age,
    COUNT(*) as count,
    m.name, b.title, bb.borrow_date
FROM borrowed_books bb
JOIN members m ON bb.member_id = m.id
JOIN books b ON bb.book_id = b.id
GROUP BY borrowing_age
ORDER BY bb.borrow_date DESC;
```

**What it does**: Categorizes borrowings by age and shows counts.

## 📊 Performance Optimization

### 1. Proper Indexing
```sql
-- Create indexes for better JOIN performance
CREATE INDEX idx_borrowed_books_member_id ON borrowed_books(member_id);
CREATE INDEX idx_borrowed_books_book_id ON borrowed_books(book_id);
CREATE INDEX idx_borrowed_books_date ON borrowed_books(borrow_date);
CREATE INDEX idx_members_name ON members(name);
CREATE INDEX idx_books_title ON books(title);
CREATE INDEX idx_books_author ON books(author);
```

### 2. Query Optimization
```sql
-- Use LIMIT for large datasets
SELECT bb.id, m.name, b.title, bb.borrow_date
FROM borrowed_books bb
JOIN members m ON bb.member_id = m.id
JOIN books b ON bb.book_id = b.id
ORDER BY bb.borrow_date DESC
LIMIT 50;

-- Use specific columns instead of *
SELECT bb.id, m.name, m.course, b.title, b.author, bb.borrow_date
FROM borrowed_books bb
JOIN members m ON bb.member_id = m.id
JOIN books b ON bb.book_id = b.id;
```

### 3. Subquery Optimization
```sql
-- Use EXISTS instead of IN for better performance
SELECT * FROM members m
WHERE EXISTS (
    SELECT 1 FROM borrowed_books bb 
    WHERE bb.member_id = m.id
);

-- Instead of:
-- WHERE m.id IN (SELECT member_id FROM borrowed_books)
```

## 🚨 Common JOIN Mistakes

### 1. Missing JOIN Conditions
```sql
-- ❌ WRONG - Missing JOIN condition
SELECT m.name, b.title
FROM members m, books b;  -- This creates a CARTESIAN PRODUCT!

-- ✅ CORRECT - With proper JOIN
SELECT m.name, b.title
FROM members m
JOIN borrowed_books bb ON m.id = bb.member_id
JOIN books b ON bb.book_id = b.id;
```

### 2. Incorrect JOIN Type
```sql
-- ❌ WRONG - Using INNER JOIN when you need all records
SELECT b.title, bb.borrow_date
FROM books b
JOIN borrowed_books bb ON b.id = bb.book_id;  -- Only shows borrowed books

-- ✅ CORRECT - Using LEFT JOIN to show all books
SELECT b.title, bb.borrow_date
FROM books b
LEFT JOIN borrowed_books bb ON b.id = bb.book_id;  -- Shows all books
```

### 3. Over-JOINING
```sql
-- ❌ WRONG - Unnecessary JOINs
SELECT m.name, b.title
FROM members m
JOIN borrowed_books bb ON m.id = bb.member_id
JOIN books b ON bb.book_id = b.id
JOIN members m2 ON m.id = m2.id;  -- Unnecessary!

-- ✅ CORRECT - Only necessary JOINs
SELECT m.name, b.title
FROM members m
JOIN borrowed_books bb ON m.id = bb.member_id
JOIN books b ON bb.book_id = b.id;
```

## 📋 JOIN Cheat Sheet

| JOIN Type | Use Case | Example |
|-----------|----------|---------|
| **INNER JOIN** | Only matching records | Current borrowings |
| **LEFT JOIN** | All left + matching right | All books with status |
| **RIGHT JOIN** | All right + matching left | All members with history |
| **FULL JOIN** | All records from both | Complete overview |

---

**Previous: [CREATE.md](CREATE.md) - Database Creation & CRUD Operations**  
**Next: [DATABASE.md](DATABASE.md) - Database Configuration & Switching**
