<?php
session_start();
require_once '../config/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'add':
            addBorrowedBook();
            break;
        case 'update':
            updateBorrowedBook();
            break;
        case 'delete':
            deleteBorrowedBook();
            break;
        default:
            $_SESSION['message'] = 'Invalid action specified.';
            $_SESSION['message_type'] = 'danger';
            header('Location: ../borrowed.php');
            exit;
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = $_GET['action'] ?? '';
    
    switch ($action) {
        case 'delete':
            deleteBorrowedBook();
            break;
        default:
            $_SESSION['message'] = 'Invalid action specified.';
            $_SESSION['message_type'] = 'danger';
            header('Location: ../borrowed.php');
            exit;
    }
}

function addBorrowedBook() {
    $memberId = (int)($_POST['member_id'] ?? 0);
    $bookId = (int)($_POST['book_id'] ?? 0);
    $borrowDate = $_POST['borrow_date'] ?? '';
    
    // Validation
    if ($memberId <= 0 || $bookId <= 0 || empty($borrowDate)) {
        $_SESSION['message'] = 'All fields are required and IDs must be valid.';
        $_SESSION['message_type'] = 'danger';
        header('Location: ../borrowed.php');
        exit;
    }
    
    try {
        global $pdo;
        
        // Check if member exists
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM members WHERE id = ?");
        $stmt->execute([$memberId]);
        if ($stmt->fetchColumn() == 0) {
            $_SESSION['message'] = 'Selected member does not exist.';
            $_SESSION['message_type'] = 'danger';
            header('Location: ../borrowed.php');
            exit;
        }
        
        // Check if book exists
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM books WHERE id = ?");
        $stmt->execute([$bookId]);
        if ($stmt->fetchColumn() == 0) {
            $_SESSION['message'] = 'Selected book does not exist.';
            $_SESSION['message_type'] = 'danger';
            header('Location: ../borrowed.php');
            exit;
        }
        
        // Check if book is already borrowed
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM borrowed_books WHERE book_id = ?");
        $stmt->execute([$bookId]);
        if ($stmt->fetchColumn() > 0) {
            $_SESSION['message'] = 'This book is already borrowed by another member.';
            $_SESSION['message_type'] = 'warning';
            header('Location: ../borrowed.php');
            exit;
        }
        
        // Insert borrowed book record
        $stmt = $pdo->prepare("INSERT INTO borrowed_books (member_id, book_id, borrow_date) VALUES (?, ?, ?)");
        $stmt->execute([$memberId, $bookId, $borrowDate]);
        
        $_SESSION['message'] = 'Book borrowed successfully!';
        $_SESSION['message_type'] = 'success';
        $_SESSION['show_toast'] = true;
        
    } catch (PDOException $e) {
        $_SESSION['message'] = 'Error borrowing book: ' . $e->getMessage();
        $_SESSION['message_type'] = 'danger';
        $_SESSION['show_toast'] = true;
    }
    
    header('Location: ../borrowed.php');
    exit;
}

function updateBorrowedBook() {
    $id = (int)($_POST['id'] ?? 0);
    $memberId = (int)($_POST['member_id'] ?? 0);
    $bookId = (int)($_POST['book_id'] ?? 0);
    $borrowDate = $_POST['borrow_date'] ?? '';
    
    // Validation
    if ($id <= 0 || $memberId <= 0 || $bookId <= 0 || empty($borrowDate)) {
        $_SESSION['message'] = 'All fields are required and IDs must be valid.';
        $_SESSION['message_type'] = 'danger';
        header('Location: ../borrowed.php');
        exit;
    }
    
    try {
        global $pdo;
        
        // Check if member exists
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM members WHERE id = ?");
        $stmt->execute([$memberId]);
        if ($stmt->fetchColumn() == 0) {
            $_SESSION['message'] = 'Selected member does not exist.';
            $_SESSION['message_type'] = 'danger';
            header('Location: ../borrowed.php');
            exit;
        }
        
        // Check if book exists
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM books WHERE id = ?");
        $stmt->execute([$bookId]);
        if ($stmt->fetchColumn() == 0) {
            $_SESSION['message'] = 'Selected book does not exist.';
            $_SESSION['message_type'] = 'danger';
            header('Location: ../borrowed.php');
            exit;
        }
        
        // Check if book is already borrowed by another member
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM borrowed_books WHERE book_id = ? AND id != ?");
        $stmt->execute([$bookId, $id]);
        if ($stmt->fetchColumn() > 0) {
            $_SESSION['message'] = 'This book is already borrowed by another member.';
            $_SESSION['message_type'] = 'warning';
            header('Location: ../borrowed.php');
            exit;
        }
        
        // Update borrowed book record
        $stmt = $pdo->prepare("UPDATE borrowed_books SET member_id = ?, book_id = ?, borrow_date = ? WHERE id = ?");
        $stmt->execute([$memberId, $bookId, $borrowDate, $id]);
        
        if ($stmt->rowCount() > 0) {
            $_SESSION['message'] = 'Borrowed book record updated successfully!';
            $_SESSION['message_type'] = 'success';
            $_SESSION['show_toast'] = true;
        } else {
            $_SESSION['message'] = 'No changes were made or record not found.';
            $_SESSION['message_type'] = 'warning';
            $_SESSION['show_toast'] = true;
        }
        
    } catch (PDOException $e) {
        $_SESSION['message'] = 'Error updating borrowed book record: ' . $e->getMessage();
        $_SESSION['message_type'] = 'danger';
        $_SESSION['show_toast'] = true;
    }
    
    header('Location: ../borrowed.php');
    exit;
}

function deleteBorrowedBook() {
    $id = (int)($_GET['id'] ?? 0);
    
    if ($id <= 0) {
        $_SESSION['message'] = 'Invalid borrowed book ID.';
        $_SESSION['message_type'] = 'danger';
        header('Location: ../borrowed.php');
        exit;
    }
    
    try {
        global $pdo;
        
        // Get book information before deletion
        $stmt = $pdo->prepare("
            SELECT b.title, m.name as member_name 
            FROM borrowed_books bb
            JOIN books b ON bb.book_id = b.id
            JOIN members m ON bb.member_id = m.id
            WHERE bb.id = ?
        ");
        $stmt->execute([$id]);
        $borrowedInfo = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$borrowedInfo) {
            $_SESSION['message'] = 'Borrowed book record not found.';
            $_SESSION['message_type'] = 'warning';
            header('Location: ../borrowed.php');
            exit;
        }
        
        // Delete borrowed book record
        $stmt = $pdo->prepare("DELETE FROM borrowed_books WHERE id = ?");
        $stmt->execute([$id]);
        
        if ($stmt->rowCount() > 0) {
            $_SESSION['message'] = 'Book returned successfully! "' . $borrowedInfo['title'] . '" has been returned by ' . $borrowedInfo['member_name'] . '.';
            $_SESSION['message_type'] = 'success';
            $_SESSION['show_toast'] = true;
        } else {
            $_SESSION['message'] = 'Record not found.';
            $_SESSION['message_type'] = 'warning';
            $_SESSION['show_toast'] = true;
        }
        
    } catch (PDOException $e) {
        $_SESSION['message'] = 'Error returning book: ' . $e->getMessage();
        $_SESSION['message_type'] = 'danger';
        $_SESSION['show_toast'] = true;
    }
    
    header('Location: ../borrowed.php');
    exit;
}
?>
