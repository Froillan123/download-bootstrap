<?php
session_start();
require_once '../config/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'add':
            addMember();
            break;
        case 'update':
            updateMember();
            break;
        case 'delete':
            deleteMember();
            break;
        default:
            $_SESSION['message'] = 'Invalid action specified.';
            $_SESSION['message_type'] = 'danger';
            header('Location: ../members.php');
            exit;
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = $_GET['action'] ?? '';
    
    switch ($action) {
        case 'view':
            viewMember();
            break;
        case 'delete':
            deleteMember();
            break;
        default:
            $_SESSION['message'] = 'Invalid action specified.';
            $_SESSION['message_type'] = 'danger';
            header('Location: ../members.php');
            exit;
    }
}

function addMember() {
    $name = sanitizeInput($_POST['name'] ?? '');
    $course = sanitizeInput($_POST['course'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    
    // Validation
    if (empty($name) || empty($course) || empty($email)) {
        $_SESSION['message'] = 'All fields are required.';
        $_SESSION['message_type'] = 'danger';
        header('Location: ../members.php');
        exit;
    }
    
    if (!isValidEmail($email)) {
        $_SESSION['message'] = 'Please enter a valid email address.';
        $_SESSION['message_type'] = 'danger';
        header('Location: ../members.php');
        exit;
    }
    
    try {
        global $pdo;
        
        // Check if email already exists
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM members WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetchColumn() > 0) {
            $_SESSION['message'] = 'A member with this email already exists.';
            $_SESSION['message_type'] = 'danger';
            header('Location: ../members.php');
            exit;
        }
        
        // Insert new member
        $stmt = $pdo->prepare("INSERT INTO members (name, course, email) VALUES (?, ?, ?)");
        $stmt->execute([$name, $course, $email]);
        
        $_SESSION['message'] = 'Member added successfully!';
        $_SESSION['message_type'] = 'success';
        $_SESSION['show_toast'] = true;
        
    } catch (PDOException $e) {
        $_SESSION['message'] = 'Error adding member: ' . $e->getMessage();
        $_SESSION['message_type'] = 'danger';
        $_SESSION['show_toast'] = true;
    }
    
    header('Location: ../members.php');
    exit;
}

function updateMember() {
    $id = (int)($_POST['id'] ?? 0);
    $name = sanitizeInput($_POST['name'] ?? '');
    $course = sanitizeInput($_POST['course'] ?? '');
    $email = sanitizeInput($_POST['email'] ?? '');
    
    // Validation
    if ($id <= 0 || empty($name) || empty($course) || empty($email)) {
        $_SESSION['message'] = 'All fields are required and ID must be valid.';
        $_SESSION['message_type'] = 'danger';
        header('Location: ../members.php');
        exit;
    }
    
    if (!isValidEmail($email)) {
        $_SESSION['message'] = 'Please enter a valid email address.';
        $_SESSION['message_type'] = 'danger';
        header('Location: ../members.php');
        exit;
    }
    
    try {
        global $pdo;
        
        // Check if email already exists for other members
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM members WHERE email = ? AND id != ?");
        $stmt->execute([$email, $id]);
        if ($stmt->fetchColumn() > 0) {
            $_SESSION['message'] = 'A member with this email already exists.';
            $_SESSION['message_type'] = 'danger';
            header('Location: ../members.php');
            exit;
        }
        
        // Update member
        $stmt = $pdo->prepare("UPDATE members SET name = ?, course = ?, email = ? WHERE id = ?");
        $stmt->execute([$name, $course, $email, $id]);
        
        if ($stmt->rowCount() > 0) {
            $_SESSION['message'] = 'Member updated successfully!';
            $_SESSION['message_type'] = 'success';
            $_SESSION['show_toast'] = true;
        } else {
            $_SESSION['message'] = 'No changes were made or member not found.';
            $_SESSION['message_type'] = 'warning';
            $_SESSION['show_toast'] = true;
        }
        
    } catch (PDOException $e) {
        $_SESSION['message'] = 'Error updating member: ' . $e->getMessage();
        $_SESSION['message_type'] = 'danger';
        $_SESSION['show_toast'] = true;
    }
    
    header('Location: ../members.php');
    exit;
}

function deleteMember() {
    $id = (int)($_GET['id'] ?? 0);
    
    if ($id <= 0) {
        $_SESSION['message'] = 'Invalid member ID.';
        $_SESSION['message_type'] = 'danger';
        header('Location: ../members.php');
        exit;
    }
    
    try {
        global $pdo;
        
        // Check if member has borrowed books
        if (memberHasBorrowedBooks($id)) {
            $_SESSION['message'] = 'Cannot delete member with borrowed books. Please return all books first.';
            $_SESSION['message_type'] = 'warning';
            header('Location: ../members.php');
            exit;
        }
        
        // Delete member
        $stmt = $pdo->prepare("DELETE FROM members WHERE id = ?");
        $stmt->execute([$id]);
        
        if ($stmt->rowCount() > 0) {
            $_SESSION['message'] = 'Member deleted successfully!';
            $_SESSION['message_type'] = 'success';
            $_SESSION['show_toast'] = true;
        } else {
            $_SESSION['message'] = 'Member not found.';
            $_SESSION['message_type'] = 'warning';
            $_SESSION['show_toast'] = true;
        }
        
    } catch (PDOException $e) {
        $_SESSION['message'] = 'Error deleting member: ' . $e->getMessage();
        $_SESSION['message_type'] = 'danger';
        $_SESSION['show_toast'] = true;
    }
    
    header('Location: ../members.php');
    exit;
}

function viewMember() {
    $id = (int)($_GET['id'] ?? 0);
    
    if ($id <= 0) {
        echo '<div class="alert alert-danger">Invalid member ID.</div>';
        return;
    }
    
    try {
        $member = getMemberById($id);
        if (!$member) {
            echo '<div class="alert alert-warning">Member not found.</div>';
            return;
        }
        
        $borrowedBooks = getMemberBorrowedBooks($id);
        
        echo '<div class="row">';
        echo '<div class="col-md-6">';
        echo '<h6>Member Information</h6>';
        echo '<table class="table table-borderless">';
        echo '<tr><td><strong>ID:</strong></td><td>' . $member['id'] . '</td></tr>';
        echo '<tr><td><strong>Name:</strong></td><td>' . htmlspecialchars($member['name']) . '</td></tr>';
        echo '<tr><td><strong>Course:</strong></td><td>' . htmlspecialchars($member['course']) . '</td></tr>';
        echo '<tr><td><strong>Email:</strong></td><td>' . htmlspecialchars($member['email']) . '</td></tr>';
        echo '<tr><td><strong>Created:</strong></td><td>' . formatDate($member['created_at']) . '</td></tr>';
        echo '</table>';
        echo '</div>';
        
        echo '<div class="col-md-6">';
        echo '<h6>Borrowed Books (' . count($borrowedBooks) . ')</h6>';
        if (empty($borrowedBooks)) {
            echo '<p class="text-muted">No books currently borrowed.</p>';
        } else {
            echo '<div class="list-group list-group-flush">';
            foreach ($borrowedBooks as $book) {
                echo '<div class="list-group-item d-flex justify-content-between align-items-center">';
                echo '<div>';
                echo '<strong>' . htmlspecialchars($book['title']) . '</strong><br>';
                echo '<small class="text-muted">by ' . htmlspecialchars($book['author']) . '</small>';
                echo '</div>';
                echo '<small class="text-muted">' . formatDate($book['borrow_date']) . '</small>';
                echo '</div>';
            }
            echo '</div>';
        }
        echo '</div>';
        echo '</div>';
        
    } catch (PDOException $e) {
        echo '<div class="alert alert-danger">Error loading member details: ' . $e->getMessage() . '</div>';
    }
}
?>
