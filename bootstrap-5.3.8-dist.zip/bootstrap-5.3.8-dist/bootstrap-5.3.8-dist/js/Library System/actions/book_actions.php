<?php
session_start();
require_once '../config/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    switch ($action) {
        case 'add':
            addBook();
            break;
        case 'update':
            updateBook();
            break;
        case 'delete':
            deleteBook();
            break;
        default:
            $_SESSION['message'] = 'Invalid action specified.';
            $_SESSION['message_type'] = 'danger';
            header('Location: ../books.php');
            exit;
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = $_GET['action'] ?? '';
    
    switch ($action) {
        case 'view':
            viewBook();
            break;
        case 'delete':
            deleteBook();
            break;
        default:
            $_SESSION['message'] = 'Invalid action specified.';
            $_SESSION['message_type'] = 'danger';
            header('Location: ../books.php');
            exit;
    }
}

function addBook() {
    $title = sanitizeInput($_POST['title'] ?? '');
    $author = sanitizeInput($_POST['author'] ?? '');
    
    // Validation
    if (empty($title) || empty($author)) {
        $_SESSION['message'] = 'Both title and author are required.';
        $_SESSION['message_type'] = 'danger';
        header('Location: ../books.php');
        exit;
    }
    
    try {
        global $pdo;
        
        // Check if book already exists (same title and author)
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM books WHERE title = ? AND author = ?");
        $stmt->execute([$title, $author]);
        if ($stmt->fetchColumn() > 0) {
            $_SESSION['message'] = 'A book with this title and author already exists.';
            $_SESSION['message_type'] = 'warning';
            header('Location: ../books.php');
            exit;
        }
        
        // Insert new book
        $stmt = $pdo->prepare("INSERT INTO books (title, author) VALUES (?, ?)");
        $stmt->execute([$title, $author]);
        
        $_SESSION['message'] = 'Book added successfully!';
        $_SESSION['message_type'] = 'success';
        $_SESSION['show_toast'] = true;
        
    } catch (PDOException $e) {
        $_SESSION['message'] = 'Error adding book: ' . $e->getMessage();
        $_SESSION['message_type'] = 'danger';
        $_SESSION['show_toast'] = true;
    }
    
    header('Location: ../books.php');
    exit;
}

function updateBook() {
    $id = (int)($_POST['id'] ?? 0);
    $title = sanitizeInput($_POST['title'] ?? '');
    $author = sanitizeInput($_POST['author'] ?? '');
    
    // Validation
    if ($id <= 0 || empty($title) || empty($author)) {
        $_SESSION['message'] = 'All fields are required and ID must be valid.';
        $_SESSION['message_type'] = 'danger';
        header('Location: ../books.php');
        exit;
    }
    
    try {
        global $pdo;
        
        // Check if book already exists for other books (same title and author)
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM books WHERE title = ? AND author = ? AND id != ?");
        $stmt->execute([$title, $author, $id]);
        if ($stmt->fetchColumn() > 0) {
            $_SESSION['message'] = 'A book with this title and author already exists.';
            $_SESSION['message_type'] = 'warning';
            header('Location: ../books.php');
            exit;
        }
        
        // Update book
        $stmt = $pdo->prepare("UPDATE books SET title = ?, author = ? WHERE id = ?");
        $stmt->execute([$title, $author, $id]);
        
        if ($stmt->rowCount() > 0) {
            $_SESSION['message'] = 'Book updated successfully!';
            $_SESSION['message_type'] = 'success';
            $_SESSION['show_toast'] = true;
        } else {
            $_SESSION['message'] = 'No changes were made or book not found.';
            $_SESSION['message_type'] = 'warning';
            $_SESSION['show_toast'] = true;
        }
        
    } catch (PDOException $e) {
        $_SESSION['message'] = 'Error updating book: ' . $e->getMessage();
        $_SESSION['message_type'] = 'danger';
        $_SESSION['show_toast'] = true;
    }
    
    header('Location: ../books.php');
    exit;
}

function deleteBook() {
    $id = (int)($_GET['id'] ?? 0);
    
    if ($id <= 0) {
        $_SESSION['message'] = 'Invalid book ID.';
        $_SESSION['message_type'] = 'danger';
        header('Location: ../books.php');
        exit;
    }
    
    try {
        global $pdo;
        
        // Check if book is currently borrowed
        if (bookIsBorrowed($id)) {
            $_SESSION['message'] = 'Cannot delete book that is currently borrowed. Please return it first.';
            $_SESSION['message_type'] = 'warning';
            header('Location: ../books.php');
            exit;
        }
        
        // Delete book
        $stmt = $pdo->prepare("DELETE FROM books WHERE id = ?");
        $stmt->execute([$id]);
        
        if ($stmt->rowCount() > 0) {
            $_SESSION['message'] = 'Book deleted successfully!';
            $_SESSION['message_type'] = 'success';
            $_SESSION['show_toast'] = true;
        } else {
            $_SESSION['message'] = 'Book not found.';
            $_SESSION['message_type'] = 'warning';
            $_SESSION['show_toast'] = true;
        }
        
    } catch (PDOException $e) {
        $_SESSION['message'] = 'Error deleting book: ' . $e->getMessage();
        $_SESSION['message_type'] = 'danger';
        $_SESSION['show_toast'] = true;
    }
    
    header('Location: ../books.php');
    exit;
}

function viewBook() {
    $id = (int)($_GET['id'] ?? 0);
    
    if ($id <= 0) {
        echo '<div class="alert alert-danger">Invalid book ID.</div>';
        return;
    }
    
    try {
        $book = getBookById($id);
        if (!$book) {
            echo '<div class="alert alert-warning">Book not found.</div>';
            return;
        }
        
        $isBorrowed = bookIsBorrowed($id);
        $borrowedInfo = null;
        
        if ($isBorrowed) {
            // Get borrowing information
            global $pdo;
            $stmt = $pdo->prepare("
                SELECT bb.borrow_date, m.name as member_name, m.course, m.email
                FROM borrowed_books bb
                JOIN members m ON bb.member_id = m.id
                WHERE bb.book_id = ?
            ");
            $stmt->execute([$id]);
            $borrowedInfo = $stmt->fetch(PDO::FETCH_ASSOC);
        }
        
        echo '<div class="row">';
        echo '<div class="col-md-6">';
        echo '<h6>Book Information</h6>';
        echo '<table class="table table-borderless">';
        echo '<tr><td><strong>ID:</strong></td><td>' . $book['id'] . '</td></tr>';
        echo '<tr><td><strong>Title:</strong></td><td>' . htmlspecialchars($book['title']) . '</td></tr>';
        echo '<tr><td><strong>Author:</strong></td><td>' . htmlspecialchars($book['author']) . '</td></tr>';
        echo '<tr><td><strong>Status:</strong></td><td>';
        if ($isBorrowed) {
            echo '<span class="badge bg-warning">Borrowed</span>';
        } else {
            echo '<span class="badge bg-success">Available</span>';
        }
        echo '</td></tr>';
        echo '<tr><td><strong>Created:</strong></td><td>' . formatDate($book['created_at']) . '</td></tr>';
        echo '</table>';
        echo '</div>';
        
        echo '<div class="col-md-6">';
        if ($isBorrowed && $borrowedInfo) {
            echo '<h6>Borrowing Information</h6>';
            echo '<table class="table table-borderless">';
            echo '<tr><td><strong>Borrowed by:</strong></td><td>' . htmlspecialchars($borrowedInfo['member_name']) . '</td></tr>';
            echo '<tr><td><strong>Course:</strong></td><td>' . htmlspecialchars($borrowedInfo['course']) . '</td></tr>';
            echo '<tr><td><strong>Email:</strong></td><td>' . htmlspecialchars($borrowedInfo['email']) . '</td></tr>';
            echo '<tr><td><strong>Borrow Date:</strong></td><td>' . formatDate($borrowedInfo['borrow_date']) . '</td></tr>';
            echo '</table>';
        } else {
            echo '<h6>Availability</h6>';
            echo '<div class="alert alert-success">';
            echo '<i class="bi bi-check-circle"></i> This book is currently available for borrowing.';
            echo '</div>';
        }
        echo '</div>';
        echo '</div>';
        
    } catch (PDOException $e) {
        echo '<div class="alert alert-danger">Error loading book details: ' . $e->getMessage() . '</div>';
    }
}
?>
