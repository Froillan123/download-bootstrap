# 🗄️ Database Creation & CRUD Operations

## 📋 Database Schema

### Tables Structure

#### members
```sql
CREATE TABLE members (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(255) NOT NULL,
    course VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

#### books
```sql
CREATE TABLE books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

#### borrowed_books (Join Table)
```sql
CREATE TABLE borrowed_books (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    member_id INTEGER,
    book_id INTEGER,
    borrow_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
);
```

## 🔧 CRUD Operations

### Create (INSERT)

#### Add Member
```php
// PHP Code
INSERT INTO members (name, course, email) VALUES (?, ?, ?)

// Example Data
INSERT INTO members (name, course, email) VALUES 
('John Doe', 'BSIT', 'john.doe@email.com'),
('Jane Smith', 'BSCS', 'jane.smith@email.com');
```

#### Add Book
```php
// PHP Code
INSERT INTO books (title, author) VALUES (?, ?)

// Example Data
INSERT INTO books (title, author) VALUES 
('PHP Programming', 'John Smith'),
('Database Design', 'Maria Garcia');
```

#### Borrow Book
```php
// PHP Code
INSERT INTO borrowed_books (member_id, book_id, borrow_date) VALUES (?, ?, NOW())

// Example Data
INSERT INTO borrowed_books (member_id, book_id, borrow_date) VALUES 
(1, 1, '2024-01-15 10:30:00'),
(2, 2, '2024-01-15 11:00:00');
```

### Read (SELECT)

#### View All Members
```sql
SELECT id, name, course, email, created_at 
FROM members 
ORDER BY name;
```

#### View All Books
```sql
SELECT id, title, author, created_at 
FROM books 
ORDER BY title;
```

#### View All Borrowed Books (JOIN)
```sql
SELECT bb.id, m.name, m.course, b.title, b.author, bb.borrow_date 
FROM borrowed_books bb
JOIN members m ON bb.member_id = m.id
JOIN books b ON bb.book_id = b.id
ORDER BY bb.borrow_date DESC;
```

#### Search by Member Name
```sql
SELECT bb.id, m.name, m.course, b.title, b.author, bb.borrow_date 
FROM borrowed_books bb
JOIN members m ON bb.member_id = m.id
JOIN books b ON bb.book_id = b.id
WHERE m.name LIKE '%John%';
```

#### Search by Book Title
```sql
SELECT bb.id, m.name, m.course, b.title, b.author, bb.borrow_date 
FROM borrowed_books bb
JOIN members m ON bb.member_id = m.id
JOIN books b ON bb.book_id = b.id
WHERE b.title LIKE '%PHP%';
```

### Update (UPDATE)

#### Update Member
```sql
-- PHP Code
UPDATE members SET name = ?, course = ?, email = ? WHERE id = ?

-- Example
UPDATE members 
SET name = 'John Michael Doe', course = 'BSIT-3A' 
WHERE id = 1;
```

#### Update Book
```sql
-- PHP Code
UPDATE books SET title = ?, author = ? WHERE id = ?

-- Example
UPDATE books 
SET title = 'Advanced PHP Programming', author = 'John Smith Jr.' 
WHERE id = 1;
```

#### Update Borrowed Book
```sql
-- PHP Code
UPDATE borrowed_books SET member_id = ?, book_id = ?, borrow_date = ? WHERE id = ?

-- Example
UPDATE borrowed_books 
SET borrow_date = '2024-01-16 09:00:00' 
WHERE id = 1;
```

### Delete (DELETE)

#### Return Book (Delete Borrowed Record)
```sql
-- PHP Code
DELETE FROM borrowed_books WHERE id = ?

-- Example
DELETE FROM borrowed_books WHERE id = 1;
```

#### Delete Member (with borrowed books check)
```sql
-- PHP Code
DELETE FROM members 
WHERE id = ? AND id NOT IN (SELECT member_id FROM borrowed_books);

-- Example
DELETE FROM members 
WHERE id = 1 AND id NOT IN (SELECT member_id FROM borrowed_books);
```

#### Delete Book (with borrowed check)
```sql
-- PHP Code
DELETE FROM books 
WHERE id = ? AND id NOT IN (SELECT book_id FROM borrowed_books);

-- Example
DELETE FROM books 
WHERE id = 1 AND id NOT IN (SELECT book_id FROM borrowed_books);
```

## 📊 Sample Data

### Sample Members
```sql
INSERT INTO members (name, course, email) VALUES 
('John Doe', 'BSIT', 'john.doe@email.com'),
('Jane Smith', 'BSCS', 'jane.smith@email.com'),
('Mike Johnson', 'BSIT', 'mike.johnson@email.com'),
('Sarah Wilson', 'BSCS', 'sarah.wilson@email.com'),
('David Lee', 'BSIT', 'david.lee@email.com');
```

### Sample Books
```sql
INSERT INTO books (title, author) VALUES 
('PHP Programming', 'John Smith'),
('Database Design', 'Maria Garcia'),
('Web Development', 'David Lee'),
('JavaScript Basics', 'Sarah Wilson'),
('Python for Beginners', 'Mike Johnson');
```

### Sample Borrowed Books
```sql
INSERT INTO borrowed_books (member_id, book_id, borrow_date) VALUES 
(1, 1, '2024-01-15 10:30:00'),
(2, 2, '2024-01-15 11:00:00'),
(3, 3, '2024-01-15 14:20:00'),
(4, 4, '2024-01-16 09:15:00'),
(5, 5, '2024-01-16 13:45:00');
```

## 🔍 Advanced Queries

### Count Statistics
```sql
-- Total Members
SELECT COUNT(*) as total_members FROM members;

-- Total Books
SELECT COUNT(*) as total_books FROM books;

-- Total Borrowed Books
SELECT COUNT(*) as borrowed_books FROM borrowed_books;

-- Available Books
SELECT COUNT(*) as available_books 
FROM books 
WHERE id NOT IN (SELECT book_id FROM borrowed_books);
```

### Recent Activity
```sql
-- Books borrowed in last 7 days
SELECT bb.id, m.name, b.title, bb.borrow_date
FROM borrowed_books bb
JOIN members m ON bb.member_id = m.id
JOIN books b ON bb.book_id = b.id
WHERE bb.borrow_date >= DATE_SUB(NOW(), INTERVAL 7 DAY)
ORDER BY bb.borrow_date DESC;
```

### Member Borrowing History
```sql
-- Show all books borrowed by a specific member
SELECT b.title, b.author, bb.borrow_date
FROM borrowed_books bb
JOIN books b ON bb.book_id = b.id
WHERE bb.member_id = 1
ORDER BY bb.borrow_date DESC;
```

## ⚠️ Important Notes

### Data Integrity
- **Foreign Key Constraints**: Prevent orphaned records
- **Cascade Deletion**: Related records are handled properly
- **Validation**: All inputs are validated and sanitized

### Security
- **Prepared Statements**: Prevent SQL injection
- **Input Sanitization**: Clean user inputs
- **Email Validation**: Verify email format

### Performance
- **Indexes**: Create indexes on foreign keys
- **Efficient Queries**: Use appropriate JOIN types
- **Limit Results**: Use LIMIT for large datasets

---

**Next: [JOIN.md](JOIN.md) - Advanced JOIN Operations**
