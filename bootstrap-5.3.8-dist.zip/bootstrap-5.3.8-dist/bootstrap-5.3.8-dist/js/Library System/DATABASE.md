# 🗄️ Database Configuration & Switching

## 🔧 Database Support

The Library System supports **two database types**:
- **MySQL** (via XAMPP)
- **SQLite** (file-based)

You can easily switch between them by editing the configuration file.

## ⚙️ Configuration File

**File**: `config/database.php`

### Basic Structure
```php
<?php
// Choose your database type: 'mysql' or 'sqlite'
define('DB_TYPE', 'mysql'); // Change this line to switch databases

if (DB_TYPE === 'mysql') {
    // MySQL Configuration
    // ... MySQL setup code
} else {
    // SQLite Configuration
    // ... SQLite setup code
}
?>
```

## 🐬 MySQL Configuration (XAMPP)

### Complete MySQL Setup
```php
// Choose your database type: 'mysql' or 'sqlite'
define('DB_TYPE', 'mysql');

if (DB_TYPE === 'mysql') {
    // MySQL Configuration (XAMPP)
    define('DB_HOST', 'localhost');
    define('DB_NAME', 'library_system');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    
    try {
        $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        createMySQLTables($pdo);
    } catch(PDOException $e) {
        die("MySQL Connection failed: " . $e->getMessage());
    }
}
```

### MySQL Table Creation
```php
function createMySQLTables($pdo) {
    // Members table
    $pdo->exec("CREATE TABLE IF NOT EXISTS members (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        course VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    
    // Books table
    $pdo->exec("CREATE TABLE IF NOT EXISTS books (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        author VARCHAR(255) NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    
    // Borrowed books table
    $pdo->exec("CREATE TABLE IF NOT EXISTS borrowed_books (
        id INT AUTO_INCREMENT PRIMARY KEY,
        member_id INT,
        book_id INT,
        borrow_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
        FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
    )");
}
```

### XAMPP Setup Steps

1. **Start XAMPP Services**
   ```
   - Start Apache
   - Start MySQL
   ```

2. **Create Database**
   - Open phpMyAdmin: `http://localhost/phpmyadmin`
   - Click "New" on the left sidebar
   - Enter database name: `library_system`
   - Click "Create"

3. **Verify Connection**
   - Check if you can access the database
   - Tables will be created automatically when you first visit the system

## 🗃️ SQLite Configuration

### Complete SQLite Setup
```php
// Choose your database type: 'mysql' or 'sqlite'
define('DB_TYPE', 'sqlite');

if (DB_TYPE === 'sqlite') {
    // SQLite Configuration
    define('DB_FILE', 'database/library.db');
    
    try {
        $pdo = new PDO("sqlite:" . DB_FILE);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        createSQLiteTables($pdo);
    } catch(PDOException $e) {
        die("SQLite Connection failed: " . $e->getMessage());
    }
}
```

### SQLite Table Creation
```php
function createSQLiteTables($pdo) {
    // Members table
    $pdo->exec("CREATE TABLE IF NOT EXISTS members (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        course TEXT NOT NULL,
        email TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    
    // Books table
    $pdo->exec("CREATE TABLE IF NOT EXISTS books (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        author TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
    
    // Borrowed books table
    $pdo->exec("CREATE TABLE IF NOT EXISTS borrowed_books (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        member_id INTEGER,
        book_id INTEGER,
        borrow_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (member_id) REFERENCES members(id) ON DELETE CASCADE,
        FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
    )");
}
```

### SQLite Setup Steps

1. **Create Database Directory**
   ```
   mkdir database
   ```

2. **Set Permissions** (Linux/Mac)
   ```
   chmod 755 database/
   chmod 666 database/library.db  # After creation
   ```

3. **Verify Connection**
   - Database file will be created automatically
   - Tables will be created on first visit

## 🔄 Database Switching Guide

### From MySQL to SQLite

1. **Edit Configuration**
   ```php
   // Change this line in config/database.php
   define('DB_TYPE', 'sqlite');  // Was 'mysql'
   ```

2. **Create Database Directory** (if not exists)
   ```
   mkdir database
   ```

3. **Refresh Page**
   - Visit any page in your system
   - SQLite database will be created automatically
   - Tables will be created with fresh structure

4. **Note**: Your MySQL data will be preserved but won't transfer to SQLite

### From SQLite to MySQL

1. **Create MySQL Database**
   - Open phpMyAdmin: `http://localhost/phpmyadmin`
   - Create database named `library_system`

2. **Edit Configuration**
   ```php
   // Change this line in config/database.php
   define('DB_TYPE', 'mysql');  // Was 'sqlite'
   ```

3. **Refresh Page**
   - Visit any page in your system
   - System will connect to MySQL
   - Tables will be created automatically

4. **Note**: Your SQLite data will be preserved but won't transfer to MySQL

## 📊 Data Migration

### Manual Migration Process

#### MySQL to SQLite
1. **Export from MySQL**
   ```sql
   -- In phpMyAdmin, export each table as CSV
   -- Or use SQL export
   SELECT * FROM members;
   SELECT * FROM books;
   SELECT * FROM borrowed_books;
   ```

2. **Import to SQLite**
   ```bash
   # Using SQLite command line
   sqlite3 database/library.db
   
   .mode csv
   .import members.csv members
   .import books.csv books
   .import borrowed_books.csv borrowed_books
   ```

#### SQLite to MySQL
1. **Export from SQLite**
   ```bash
   sqlite3 database/library.db
   
   .mode csv
   .headers on
   .output members.csv
   SELECT * FROM members;
   .output books.csv
   SELECT * FROM books;
   .output borrowed_books.csv
   SELECT * FROM borrowed_books;
   ```

2. **Import to MySQL**
   - Use phpMyAdmin import feature
   - Or use MySQL command line with LOAD DATA

### Automated Migration (Future Feature)
```php
// This could be added to the system later
function migrateData($fromType, $toType) {
    if ($fromType === 'mysql' && $toType === 'sqlite') {
        // Export MySQL data and import to SQLite
    } elseif ($fromType === 'sqlite' && $toType === 'mysql') {
        // Export SQLite data and import to MySQL
    }
}
```

## 🔍 Database Information

### Get Current Database Type
```php
function getDatabaseType() {
    return DB_TYPE === 'mysql' ? 'MySQL (XAMPP)' : 'SQLite';
}
```

### Get Database Info
```php
function getDatabaseInfo() {
    if (DB_TYPE === 'mysql') {
        return [
            'type' => 'MySQL',
            'host' => DB_HOST,
            'database' => DB_NAME,
            'user' => DB_USER
        ];
    } else {
        return [
            'type' => 'SQLite',
            'file' => DB_FILE,
            'size' => file_exists(DB_FILE) ? filesize(DB_FILE) : 0
        ];
    }
}
```

## 🚨 Troubleshooting

### MySQL Connection Issues

1. **"Connection failed"**
   - Check if XAMPP MySQL is running
   - Verify database name exists
   - Check username/password

2. **"Access denied"**
   - Verify MySQL user permissions
   - Check if user can access the database

3. **"Table doesn't exist"**
   - Refresh the page to create tables
   - Check if `createMySQLTables()` function is called

### SQLite Issues

1. **"Permission denied"**
   - Check folder permissions
   - Ensure web server can write to database directory

2. **"Database locked"**
   - Check if another process is using the database
   - Restart web server if needed

3. **"Table doesn't exist"**
   - Refresh the page to create tables
   - Check if `createSQLiteTables()` function is called

### General Issues

1. **"PDO not available"**
   - Enable PDO extension in PHP
   - Check php.ini configuration

2. **"Session start error"**
   - Remove `session_start()` from database.php
   - Add it to the top of each main page

## 📋 Configuration Checklist

### MySQL Setup
- [ ] XAMPP Apache started
- [ ] XAMPP MySQL started
- [ ] Database `library_system` created
- [ ] `DB_TYPE` set to `'mysql'`
- [ ] Connection parameters correct

### SQLite Setup
- [ ] `database/` folder exists
- [ ] Folder has write permissions
- [ ] `DB_TYPE` set to `'sqlite'`
- [ ] `DB_FILE` path is correct

### Both Databases
- [ ] PHP PDO extension enabled
- [ ] Tables created automatically
- [ ] Foreign key constraints working
- [ ] Data integrity maintained

---

**Previous: [JOIN.md](JOIN.md) - JOIN Operations & Complex Queries**  
**Next: [USAGE.md](USAGE.md) - System Usage Guide**
