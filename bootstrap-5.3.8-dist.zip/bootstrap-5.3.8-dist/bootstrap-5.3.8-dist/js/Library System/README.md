# 📚 Library System

A simple library management system built with PHP, supporting both SQLite and MySQL (XAMPP) databases. Features CRUD operations for members, books, and book borrowing with a modern Bootstrap UI.

## 🗂 Database Schema

### Tables

#### members
- `id` (INTEGER PRIMARY KEY AUTOINCREMENT)
- `name` (VARCHAR(255) NOT NULL)
- `course` (VARCHAR(255) NOT NULL)
- `email` (VARCHAR(255) NOT NULL)
- `created_at` (DATETIME DEFAULT CURRENT_TIMESTAMP)

#### books
- `id` (INTEGER PRIMARY KEY AUTOINCREMENT)
- `title` (VARCHAR(255) NOT NULL)
- `author` (VARCHAR(255) NOT NULL)
- `created_at` (DATETIME DEFAULT CURRENT_TIMESTAMP)

#### borrowed_books (Join Table)
- `id` (INTEGER PRIMARY KEY AUTOINCREMENT)
- `member_id` (INTEGER, FOREIGN KEY → members.id)
- `book_id` (INTEGER, FOREIGN KEY → books.id)
- `borrow_date` (DATETIME DEFAULT CURRENT_TIMESTAMP)

## 🖇 Relationships

- **Many-to-Many**: Members can borrow many books, books can be borrowed by many members
- **Join Table**: `borrowed_books` handles the relationship between members and books

## 🚀 Features

- ✅ Add Member (Modal)
- ✅ Add Book (Modal)
- ✅ Borrow a Book (Modal)
- ✅ View All Borrowed Books (JOIN query)
- ✅ Search Borrowed Books (by member name or book title)
- ✅ Edit/Delete Records (Modal)
- ✅ Dual Database Support (SQLite + MySQL)
- ✅ Responsive Bootstrap UI
- ✅ DataTables Integration
- ✅ Real-time Search & Filtering

## 📚 Documentation Navigation

### 🗄️ **Database & Development**
- **[CREATE.md](CREATE.md)** - CRUD operations, database schema, sample data
- **[JOIN.md](JOIN.md)** - JOIN operations, complex queries, performance optimization
- **[DATABASE.md](DATABASE.md)** - Database configuration, switching, migration

### 📖 **User & Setup**
- **[USAGE.md](USAGE.md)** - Complete system usage guide, workflows, features
- **[SETUP.md](SETUP.md)** - Installation, configuration, troubleshooting

### 📋 **Quick Reference**
- **Main README** (this file) - Overview, features, file structure
- **Database README** - Basic database setup instructions

## 🛠 Setup Instructions

### Prerequisites
- XAMPP (for MySQL)
- PHP 7.4+
- Web browser

### Installation

1. **Clone/Download** the project to your XAMPP htdocs folder
2. **Start XAMPP** services (Apache + MySQL)
3. **Configure Database**:
   - Edit `config/database.php` to choose between SQLite or MySQL
   - For MySQL: Create database named `library_system`
   - For SQLite: Database file will be created automatically

### Database Configuration

The system supports both MySQL (XAMPP) and SQLite databases. You can easily switch between them by editing `config/database.php`:

#### MySQL Configuration (XAMPP)
```php
// Choose your database type: 'mysql' or 'sqlite'
define('DB_TYPE', 'mysql');

if (DB_TYPE === 'mysql') {
    // MySQL Configuration (XAMPP)
    define('DB_HOST', 'localhost');
    define('DB_NAME', 'library_system');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    
    try {
        $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        createMySQLTables($pdo);
    } catch(PDOException $e) {
        die("MySQL Connection failed: " . $e->getMessage());
    }
}
```

#### SQLite Configuration
```php
// Choose your database type: 'mysql' or 'sqlite'
define('DB_TYPE', 'sqlite');

if (DB_TYPE === 'sqlite') {
    // SQLite Configuration
    define('DB_FILE', 'database/library.db');
    try {
        $pdo = new PDO("sqlite:" . DB_FILE);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        createSQLiteTables($pdo);
    } catch(PDOException $e) {
        die("SQLite Connection failed: " . $e->getMessage());
    }
}
```

#### How to Switch Databases

1. **From MySQL to SQLite:**
   - Change `define('DB_TYPE', 'mysql');` to `define('DB_TYPE', 'sqlite');`
   - The system will automatically create the SQLite database file
   - Your data will be preserved in MySQL but won't transfer to SQLite

2. **From SQLite to MySQL:**
   - Change `define('DB_TYPE', 'sqlite');` to `define('DB_TYPE', 'mysql');`
   - Create the MySQL database manually in phpMyAdmin
   - The system will automatically create tables in MySQL
   - Your data will be preserved in SQLite but won't transfer to MySQL

3. **Data Migration (Manual Process):**
   ```sql
   -- Export from MySQL to SQLite (using phpMyAdmin export)
   -- Or use SQLite browser to import CSV data
   -- The system will handle table creation automatically
   ```

## 📖 System Usage Guide

### 🏠 Dashboard Overview
The dashboard provides a complete overview of your library system:
- **Statistics Cards**: Total members, books, borrowed books, and available books
- **Quick Actions**: Quick access to add members, books, and borrow books
- **Recent Activity**: Latest borrowed books with member and book details
- **System Information**: Database type, current time, PHP version, and server info

### 👥 Managing Members

#### Adding a New Member
1. **From Dashboard**: Click "Add Member" button in Quick Actions
2. **From Members Page**: Click "Add Member" button at the top
3. **Fill the Form**:
   - **Name**: Full name of the member
   - **Course**: Student's course/program
   - **Email**: Valid email address (system validates format)
4. **Submit**: Member appears in the members list immediately

#### Editing Member Information
1. Click the "Edit" button (pencil icon) on any member row
2. Modal opens with pre-filled current data
3. Make your changes
4. Submit - changes are saved and reflected immediately

#### Viewing Member Details
1. Click the "View" button (eye icon) on any member row
2. Modal shows complete member information
3. Includes borrowing history if any

#### Deleting Members
- **Note**: Members with borrowed books cannot be deleted
- Click "Delete" button (trash icon) on available members
- Confirmation dialog appears
- Member is removed from the system

### 📚 Managing Books

#### Adding a New Book
1. **From Dashboard**: Click "Add Book" button in Quick Actions
2. **From Books Page**: Click "Add Book" button at the top
3. **Fill the Form**:
   - **Title**: Book title
   - **Author**: Book author
4. **Submit**: Book appears in the books list with "Available" status

#### Book Status Indicators
- **🟢 Available**: Book can be borrowed
- **🔴 Borrowed**: Book is currently borrowed by a member
- Status updates automatically when books are borrowed/returned

#### Editing Book Information
1. Click "Edit" button on any book row
2. Update title or author
3. Submit changes

#### Deleting Books
- **Note**: Borrowed books cannot be deleted
- Only available books can be removed
- Confirmation required before deletion

### 🔄 Managing Borrowed Books

#### Borrowing a Book
1. **From Dashboard**: Click "Borrow Book" button in Quick Actions
2. **From Books Page**: Click "Borrow" button on available books
3. **Fill the Form**:
   - **Select Member**: Choose from existing members
   - **Select Book**: Choose from available books
   - **Borrow Date**: Automatically set to current date/time
4. **Submit**: Book status changes to "Borrowed"

#### Viewing All Borrowed Books
1. Navigate to "Borrowed Books" page
2. **Table Shows**:
   - Member name and course
   - Book title and author
   - Borrow date
   - Days since borrowed
   - Actions (edit/return)

#### Searching Borrowed Books
- **Search Bar**: Type member name, book title, or author
- **Real-time Results**: Results update as you type
- **Filter Options**:
  - **Recent**: Borrowed within 7 days
  - **Medium**: Borrowed 8-30 days ago
  - **Old**: Borrowed more than 30 days ago

#### Returning Books
1. Click "Return" button (trash icon) on borrowed book row
2. Confirmation dialog appears
3. Book is returned and status changes to "Available"
4. Record is removed from borrowed books list

### 🔍 Advanced Features

#### Search Functionality
- **Global Search**: Search across all tables
- **Table-specific Search**: Use DataTables search in each page
- **Real-time Filtering**: Instant results as you type

#### Data Export
- **Copy**: Copy table data to clipboard
- **CSV Export**: Download data as CSV file
- **Print**: Print-friendly table view

#### Responsive Design
- **Mobile Friendly**: Works on all device sizes
- **Touch Optimized**: Easy to use on tablets and phones
- **Collapsible Navigation**: Mobile-friendly menu

### 📊 Understanding the Data

#### Member Information
- **ID**: Unique identifier (auto-generated)
- **Name**: Full name of the member
- **Course**: Academic program or course
- **Email**: Contact email address
- **Created**: When the member was added to the system

#### Book Information
- **ID**: Unique identifier (auto-generated)
- **Title**: Name of the book
- **Author**: Book author
- **Status**: Available or Borrowed
- **Created**: When the book was added to the system

#### Borrowing Records
- **ID**: Unique borrowing record identifier
- **Member**: Who borrowed the book
- **Book**: Which book was borrowed
- **Borrow Date**: When the book was borrowed
- **Duration**: How long the book has been borrowed

### 🚨 Important Notes

#### Data Integrity
- **Foreign Key Constraints**: Prevent orphaned records
- **Cascade Deletion**: Related records are handled properly
- **Validation**: All inputs are validated and sanitized

#### Security Features
- **SQL Injection Protection**: Prepared statements used
- **XSS Prevention**: Output is properly escaped
- **Input Validation**: Server-side validation for all forms

#### Performance Tips
- **Database Indexing**: Proper indexes on foreign keys
- **Efficient Queries**: Optimized JOIN operations
- **Caching**: Minimal database calls for better performance

## 🔧 CRUD Operations

### Create (INSERT)
```php
// Add Member
INSERT INTO members (name, course, email) VALUES (?, ?, ?)

// Add Book  
INSERT INTO books (title, author) VALUES (?, ?)

// Borrow Book
INSERT INTO borrowed_books (member_id, book_id, borrow_date) VALUES (?, ?, NOW())
```

### Read (SELECT)
```php
// View All Borrowed Books (JOIN)
SELECT bb.id, m.name, m.course, b.title, b.author, bb.borrow_date 
FROM borrowed_books bb
JOIN members m ON bb.member_id = m.id
JOIN books b ON bb.book_id = b.id
ORDER BY bb.borrow_date DESC

// Search by Member Name
SELECT bb.id, m.name, m.course, b.title, b.author, bb.borrow_date 
FROM borrowed_books bb
JOIN members m ON bb.member_id = m.id
JOIN books b ON bb.book_id = b.id
WHERE m.name LIKE '%search_term%'
```

### Update (UPDATE)
```php
// Update Member
UPDATE members SET name = ?, course = ?, email = ? WHERE id = ?

// Update Book
UPDATE books SET title = ?, author = ? WHERE id = ?

// Update Borrowed Book
UPDATE borrowed_books SET member_id = ?, book_id = ?, borrow_date = ? WHERE id = ?
```

### Delete (DELETE)
```php
// Delete Borrowed Record
DELETE FROM borrowed_books WHERE id = ?

// Delete Member (with borrowed books check)
DELETE FROM members WHERE id = ? AND id NOT IN (SELECT member_id FROM borrowed_books)

// Delete Book (with borrowed check)
DELETE FROM books WHERE id = ? AND id NOT IN (SELECT book_id FROM borrowed_books)
```

## 🎨 UI Components

- **Bootstrap 5.3**: Modern, responsive design
- **Modals**: All CRUD operations use modal forms
- **DataTables**: Enhanced table functionality with search/sort
- **Responsive Layout**: Works on desktop and mobile
- **Bootstrap Icons**: Beautiful icon set
- **Real-time Search**: Instant filtering and search results

## 📁 File Structure

```
Library System/
├── config/
│   ├── database.php          # Database configuration
│   └── functions.php         # Helper functions
├── database/
│   └── README.md            # Database setup instructions
├── includes/
│   ├── header.php           # Common header
│   ├── footer.php           # Common footer
│   └── modals.php           # All modal forms
├── actions/
│   ├── member_actions.php   # Member CRUD operations
│   ├── book_actions.php     # Book CRUD operations
│   └── borrowed_actions.php # Borrowed books operations
├── index.php                # Main dashboard
├── members.php              # Members management
├── books.php                # Books management
├── borrowed.php             # Borrowed books view
├── README.md                # Main documentation (this file)
├── CREATE.md                # CRUD operations & database creation
├── JOIN.md                  # JOIN operations & complex queries
├── DATABASE.md              # Database configuration & switching
├── USAGE.md                 # System usage guide
└── SETUP.md                 # Installation & setup guide
```

## 🔍 Search Functionality

The search feature works across multiple tables:
- **Member Search**: Searches in members table
- **Book Search**: Searches in books table  
- **Borrowed Books Search**: Searches across joined data

Search is implemented using:
- Real-time filtering with JavaScript
- SQL LIKE queries for database search
- Case-insensitive matching
- Duration-based filtering (recent, medium, overdue)

## 🎯 Key Features Explained

### Modal System
- All forms use Bootstrap modals for better UX
- Prevents page navigation during form submission
- Consistent styling across all operations
- Form validation and error handling

### Database Switching
- Single codebase supports both databases
- Configuration file controls which database to use
- Automatic table creation for both database types
- Seamless switching between SQLite and MySQL

### Join Queries

The system uses various JOIN operations to combine data from multiple tables:

#### 1. Basic JOIN for Borrowed Books
```sql
SELECT bb.id, m.name, m.course, b.title, b.author, bb.borrow_date 
FROM borrowed_books bb
JOIN members m ON bb.member_id = m.id
JOIN books b ON bb.book_id = b.id
ORDER BY bb.borrow_date DESC
```

#### 2. LEFT JOIN to Show All Books with Borrowing Status
```sql
SELECT b.id, b.title, b.author, 
       CASE WHEN bb.id IS NOT NULL THEN 'Borrowed' ELSE 'Available' END as status,
       m.name as borrowed_by, bb.borrow_date
FROM books b
LEFT JOIN borrowed_books bb ON b.id = bb.book_id
LEFT JOIN members m ON bb.member_id = m.id
ORDER BY b.title
```

#### 3. JOIN with Date Filtering
```sql
SELECT bb.id, m.name, m.course, b.title, b.author, bb.borrow_date,
       DATEDIFF(NOW(), bb.borrow_date) as days_borrowed
FROM borrowed_books bb
JOIN members m ON bb.member_id = m.id
JOIN books b ON bb.book_id = b.id
WHERE bb.borrow_date >= DATE_SUB(NOW(), INTERVAL 30 DAY)
ORDER BY bb.borrow_date DESC
```

#### 4. COUNT with JOIN for Statistics
```sql
SELECT 
    COUNT(DISTINCT m.id) as total_members,
    COUNT(DISTINCT b.id) as total_books,
    COUNT(bb.id) as borrowed_books,
    COUNT(DISTINCT b.id) - COUNT(bb.id) as available_books
FROM members m
CROSS JOIN books b
LEFT JOIN borrowed_books bb ON b.id = bb.book_id
```

#### 5. Search Across Multiple Tables
```sql
SELECT bb.id, m.name, m.course, b.title, b.author, bb.borrow_date
FROM borrowed_books bb
JOIN members m ON bb.member_id = m.id
JOIN books b ON bb.book_id = b.id
WHERE m.name LIKE '%search_term%' 
   OR b.title LIKE '%search_term%' 
   OR b.author LIKE '%search_term%'
ORDER BY bb.borrow_date DESC
```

### Security Features
- Input sanitization and validation
- Prepared statements to prevent SQL injection
- Email format validation
- Duplicate data prevention

## 🚨 Important Notes

- **Backup**: Always backup your database before major changes
- **Permissions**: Ensure web server has write permissions for SQLite
- **MySQL**: Create database manually in phpMyAdmin
- **Testing**: Test both database types before production use
- **Validation**: All forms include client and server-side validation

## 📋 Practical Examples & Workflows

### Example 1: Complete Library Workflow
```
1. Add Members
   ├── Add "John Doe" (BSIT)
   ├── Add "Jane Smith" (BSCS)
   └── Add "Mike Johnson" (BSIT)

2. Add Books
   ├── Add "PHP Programming" by "John Smith"
   ├── Add "Database Design" by "Maria Garcia"
   └── Add "Web Development" by "David Lee"

3. Borrow Books
   ├── John Doe borrows "PHP Programming"
   ├── Jane Smith borrows "Database Design"
   └── Mike Johnson borrows "Web Development"

4. Return Books
   ├── John Doe returns "PHP Programming"
   └── Book status changes to "Available"
```

### Example 2: Search and Filter Workflow
```
1. Search by Member Name
   ├── Type "John" in search bar
   ├── Results show John Doe's borrowed books
   └── Filter by "Recent" (last 7 days)

2. Search by Book Title
   ├── Type "PHP" in search bar
   ├── Results show "PHP Programming" book
   └── See who borrowed it and when

3. Advanced Filtering
   ├── Filter by borrowing duration
   ├── Sort by borrow date (newest first)
   └── Export results to CSV
```

### Example 3: Database Switching Workflow
```
1. Current: MySQL Database
   ├── 50 members, 100 books, 25 borrowed
   ├── Data stored in XAMPP MySQL
   └── Access via phpMyAdmin

2. Switch to SQLite
   ├── Change DB_TYPE to 'sqlite'
   ├── Refresh page
   ├── System creates SQLite database
   └── Tables are empty (fresh start)

3. Switch Back to MySQL
   ├── Change DB_TYPE to 'mysql'
   ├── Refresh page
   ├── System connects to MySQL
   └── All data is restored
```

### Example 4: Error Handling Scenarios
```
1. Try to Delete Member with Borrowed Books
   ├── Click delete on John Doe
   ├── System shows error message
   └── "Cannot delete member with active borrowings"

2. Try to Borrow Already Borrowed Book
   ├── Select "PHP Programming" book
   ├── System shows error message
   └── "Book is already borrowed"

3. Try to Add Duplicate Email
   ├── Add member with existing email
   ├── System shows error message
   └── "Email already exists"
```

## 🐛 Troubleshooting

### Common Issues

1. **Database Connection Failed**
   - Check XAMPP services are running
   - Verify database credentials in config file
   - Ensure database exists for MySQL

2. **Permission Denied (SQLite)**
   - Check folder permissions for database directory
   - Ensure web server can write to database folder

3. **Modal Not Opening**
   - Check Bootstrap CSS/JS files are loaded
   - Verify no JavaScript errors in console

4. **Search Not Working**
   - Ensure JavaScript is enabled
   - Check for console errors
   - Verify DataTables library is loaded

## 📞 Support

For issues or questions:
1. Check the troubleshooting section above
2. Verify your setup matches the requirements
3. Check browser console for JavaScript errors
4. Ensure all files are properly uploaded
5. Check database configuration settings

## 🔄 Updates & Maintenance

### Regular Tasks
- Backup database regularly
- Monitor borrowed books for overdue items
- Clean up old records as needed
- Update member information

### Performance Tips
- Use appropriate indexes on database tables
- Regular database maintenance
- Monitor query performance
- Optimize search queries

---

**Happy Coding! 📚✨**

*Built with ❤️ using PHP, Bootstrap, and modern web technologies*
