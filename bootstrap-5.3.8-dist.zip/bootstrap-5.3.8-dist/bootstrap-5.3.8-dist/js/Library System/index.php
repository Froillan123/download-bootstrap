<?php
$pageTitle = "Dashboard";
require_once 'includes/header.php';
require_once 'config/functions.php';

// Get statistics
$totalMembers = count(getAllMembers());
$totalBooks = count(getAllBooks());
$totalBorrowed = count(getAllBorrowedBooks());
$availableBooks = count(getAvailableBooks());
?>

<div class="row">
    <div class="col-12">
        <h1 class="h3 mb-4">
            <i class="bi bi-house"></i> Dashboard
        </h1>
    </div>
</div>

<!-- Statistics Cards -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Total Members</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $totalMembers; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="bi bi-people fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Total Books</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $totalBooks; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="bi bi-book fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Borrowed Books</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $totalBorrowed; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="bi bi-arrow-left-right fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Available Books</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $availableBooks; ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="bi bi-check-circle fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Actions -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="bi bi-lightning"></i> Quick Actions
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 mb-3">
                        <button class="btn btn-primary w-100" data-bs-toggle="modal" data-bs-target="#addMemberModal">
                            <i class="bi bi-person-plus"></i><br>
                            Add Member
                        </button>
                    </div>
                    <div class="col-md-3 mb-3">
                        <button class="btn btn-success w-100" data-bs-toggle="modal" data-bs-target="#addBookModal">
                            <i class="bi bi-plus-circle"></i><br>
                            Add Book
                        </button>
                    </div>
                    <div class="col-md-3 mb-3">
                        <button class="btn btn-info w-100" data-bs-toggle="modal" data-bs-target="#borrowBookModal">
                            <i class="bi bi-arrow-left-right"></i><br>
                            Borrow Book
                        </button>
                    </div>
                    <div class="col-md-3 mb-3">
                        <a href="borrowed.php" class="btn btn-warning w-100">
                            <i class="bi bi-list-ul"></i><br>
                            View All Borrowed
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Recent Activity -->
<div class="row">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="bi bi-clock-history"></i> Recent Borrowed Books
                </h5>
            </div>
            <div class="card-body">
                <?php
                $recentBorrowed = array_slice(getAllBorrowedBooks(), 0, 5);
                if (empty($recentBorrowed)) {
                    echo '<p class="text-muted">No books have been borrowed yet.</p>';
                } else {
                    echo '<div class="table-responsive">';
                    echo '<table class="table table-hover">';
                    echo '<thead><tr><th>Member</th><th>Book</th><th>Borrow Date</th></tr></thead>';
                    echo '<tbody>';
                    foreach ($recentBorrowed as $borrowed) {
                        echo '<tr>';
                        echo '<td><strong>' . htmlspecialchars($borrowed['member_name']) . '</strong><br><small class="text-muted">' . htmlspecialchars($borrowed['course']) . '</small></td>';
                        echo '<td><strong>' . htmlspecialchars($borrowed['title']) . '</strong><br><small class="text-muted">by ' . htmlspecialchars($borrowed['author']) . '</small></td>';
                        echo '<td>' . formatDate($borrowed['borrow_date']) . '</td>';
                        echo '</tr>';
                    }
                    echo '</tbody></table>';
                    echo '</div>';
                }
                ?>
            </div>
        </div>
    </div>
    
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="bi bi-info-circle"></i> System Information
                </h5>
            </div>
            <div class="card-body">
                <div class="mb-3">
                    <strong>Database Type:</strong><br>
                    <span class="badge bg-primary"><?php echo getDatabaseType(); ?></span>
                </div>
                <div class="mb-3">
                    <strong>Current Time:</strong><br>
                    <small class="text-muted"><?php echo date('F d, Y h:i A'); ?></small>
                </div>
                <div class="mb-3">
                    <strong>PHP Version:</strong><br>
                    <small class="text-muted"><?php echo PHP_VERSION; ?></small>
                </div>
                <div class="mb-3">
                    <strong>Server:</strong><br>
                    <small class="text-muted"><?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown'; ?></small>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/modals.php'; ?>
<?php require_once 'includes/footer.php'; ?>
