<?php
// Helper Functions for Library System
require_once 'database.php';

// Get all members
function getAllMembers() {
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM members ORDER BY name ASC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get all books
function getAllBooks() {
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM books ORDER BY title ASC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get all borrowed books with member and book details
function getAllBorrowedBooks() {
    global $pdo;
    $sql = "SELECT bb.id, bb.borrow_date, 
                   m.id as member_id, m.name as member_name, m.course, m.email,
                   b.id as book_id, b.title, b.author
            FROM borrowed_books bb
            JOIN members m ON bb.member_id = m.id
            JOIN books b ON bb.book_id = b.id
            ORDER BY bb.borrow_date DESC";
    
    $stmt = $pdo->query($sql);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Search borrowed books
function searchBorrowedBooks($searchTerm) {
    global $pdo;
    $searchTerm = "%$searchTerm%";
    
    $sql = "SELECT bb.id, bb.borrow_date, 
                   m.id as member_id, m.name as member_name, m.course, m.email,
                   b.id as book_id, b.title, b.author
            FROM borrowed_books bb
            JOIN members m ON bb.member_id = m.id
            JOIN books b ON bb.book_id = b.id
            WHERE m.name LIKE ? OR b.title LIKE ? OR b.author LIKE ?
            ORDER BY bb.borrow_date DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$searchTerm, $searchTerm, $searchTerm]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get member by ID
function getMemberById($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM members WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Get book by ID
function getBookById($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM books WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Get borrowed book by ID
function getBorrowedBookById($id) {
    global $pdo;
    $sql = "SELECT bb.id, bb.borrow_date, 
                   m.id as member_id, m.name as member_name, m.course, m.email,
                   b.id as book_id, b.title, b.author
            FROM borrowed_books bb
            JOIN members m ON bb.member_id = m.id
            JOIN books b ON bb.book_id = b.id
            WHERE bb.id = ?";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Check if member has borrowed books
function memberHasBorrowedBooks($memberId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM borrowed_books WHERE member_id = ?");
    $stmt->execute([$memberId]);
    return $stmt->fetchColumn() > 0;
}

// Check if book is currently borrowed
function bookIsBorrowed($bookId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM borrowed_books WHERE book_id = ?");
    $stmt->execute([$bookId]);
    return $stmt->fetchColumn() > 0;
}

// Get available books (not currently borrowed)
function getAvailableBooks() {
    global $pdo;
    $sql = "SELECT b.* FROM books b 
            WHERE b.id NOT IN (SELECT book_id FROM borrowed_books) 
            ORDER BY b.title ASC";
    
    $stmt = $pdo->query($sql);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get member's borrowed books
function getMemberBorrowedBooks($memberId) {
    global $pdo;
    $sql = "SELECT bb.id, bb.borrow_date, b.title, b.author
            FROM borrowed_books bb
            JOIN books b ON bb.book_id = b.id
            WHERE bb.member_id = ?
            ORDER BY bb.borrow_date DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$memberId]);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Format date for display
function formatDate($date) {
    return date('M d, Y h:i A', strtotime($date));
}

// Validate email format
function isValidEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Sanitize input
function sanitizeInput($input) {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// Get database type for display
function getDatabaseType() {
    return DB_TYPE === 'mysql' ? 'MySQL (XAMPP)' : 'SQLite';
}

// Get database info
function getDatabaseInfo() {
    global $pdo;
    if (DB_TYPE === 'mysql') {
        $stmt = $pdo->query("SELECT DATABASE() as db_name, VERSION() as version");
        $info = $stmt->fetch(PDO::FETCH_ASSOC);
        return "Database: " . $info['db_name'] . " | Version: " . $info['version'];
    } else {
        return "Database: SQLite | File: " . DB_FILE;
    }
}
?>
