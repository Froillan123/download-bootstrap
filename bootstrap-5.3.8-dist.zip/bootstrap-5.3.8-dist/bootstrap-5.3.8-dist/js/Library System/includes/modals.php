<?php
// All Modal Forms for Library System
require_once 'config/functions.php';
?>

<!-- Add Member Modal -->
<div class="modal fade" id="addMemberModal" tabindex="-1" aria-labelledby="addMemberModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addMemberModalLabel">
                    <i class="bi bi-person-plus"></i> Add New Member
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="actions/member_actions.php" method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="course" class="form-label">Course</label>
                        <input type="text" class="form-control" id="course" name="course" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="action" value="add" class="btn btn-primary">
                        <i class="bi bi-plus-circle"></i> Add Member
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Member Modal -->
<div class="modal fade" id="editMemberModal" tabindex="-1" aria-labelledby="editMemberModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editMemberModalLabel">
                    <i class="bi bi-person-gear"></i> Edit Member
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="actions/member_actions.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="id" id="edit_member_id">
                    <div class="mb-3">
                        <label for="edit_name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="edit_name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_course" class="form-label">Course</label>
                        <input type="text" class="form-control" id="edit_course" name="course" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="edit_email" name="email" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="action" value="update" class="btn btn-primary">
                        <i class="bi bi-check-circle"></i> Update Member
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Add Book Modal -->
<div class="modal fade" id="addBookModal" tabindex="-1" aria-labelledby="addBookModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addBookModalLabel">
                    <i class="bi bi-book-plus"></i> Add New Book
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="actions/book_actions.php" method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="title" class="form-label">Book Title</label>
                        <input type="text" class="form-control" id="title" name="title" required>
                    </div>
                    <div class="mb-3">
                        <label for="author" class="form-label">Author</label>
                        <input type="text" class="form-control" id="author" name="author" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="action" value="add" class="btn btn-primary">
                        <i class="bi bi-plus-circle"></i> Add Book
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Book Modal -->
<div class="modal fade" id="editBookModal" tabindex="-1" aria-labelledby="editBookModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editBookModalLabel">
                    <i class="bi bi-book-gear"></i> Edit Book
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="actions/book_actions.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="id" id="edit_book_id">
                    <div class="mb-3">
                        <label for="edit_title" class="form-label">Book Title</label>
                        <input type="text" class="form-control" id="edit_title" name="title" required>
                    </div>
                    <div class="mb-3">
                        <label for="edit_author" class="form-label">Author</label>
                        <input type="text" class="form-control" id="edit_author" name="author" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="action" value="update" class="btn btn-primary">
                        <i class="bi bi-check-circle"></i> Update Book
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Borrow Book Modal -->
<div class="modal fade" id="borrowBookModal" tabindex="-1" aria-labelledby="borrowBookModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="borrowBookModalLabel">
                    <i class="bi bi-arrow-left-right"></i> Borrow a Book
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="actions/borrowed_actions.php" method="POST">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="member_id" class="form-label">Select Member</label>
                        <select class="form-select" id="member_id" name="member_id" required>
                            <option value="">Choose a member...</option>
                            <?php
                            $members = getAllMembers();
                            foreach ($members as $member) {
                                echo "<option value='{$member['id']}'>{$member['name']} - {$member['course']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="book_id" class="form-label">Select Book</label>
                        <select class="form-select" id="book_id" name="book_id" required>
                            <option value="">Choose a book...</option>
                            <?php
                            $availableBooks = getAvailableBooks();
                            foreach ($availableBooks as $book) {
                                echo "<option value='{$book['id']}'>{$book['title']} by {$book['author']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="borrow_date" class="form-label">Borrow Date</label>
                        <input type="datetime-local" class="form-control" id="borrow_date" name="borrow_date" 
                               value="<?php echo date('Y-m-d\TH:i'); ?>" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="action" value="add" class="btn btn-success">
                        <i class="bi bi-check-circle"></i> Borrow Book
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Borrowed Book Modal -->
<div class="modal fade" id="editBorrowedModal" tabindex="-1" aria-labelledby="editBorrowedModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editBorrowedModalLabel">
                    <i class="bi bi-pencil-square"></i> Edit Borrowed Book
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="actions/borrowed_actions.php" method="POST">
                <div class="modal-body">
                    <input type="hidden" name="id" id="edit_borrowed_id">
                    <div class="mb-3">
                        <label for="edit_borrowed_member_id" class="form-label">Select Member</label>
                        <select class="form-select" id="edit_borrowed_member_id" name="member_id" required>
                            <option value="">Choose a member...</option>
                            <?php
                            foreach ($members as $member) {
                                echo "<option value='{$member['id']}'>{$member['name']} - {$member['course']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="edit_borrowed_book_id" class="form-label">Select Book</label>
                        <select class="form-select" id="edit_borrowed_book_id" name="book_id" required>
                            <option value="">Choose a book...</option>
                            <?php
                            $allBooks = getAllBooks();
                            foreach ($allBooks as $book) {
                                echo "<option value='{$book['id']}'>{$book['title']} by {$book['author']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="edit_borrow_date" class="form-label">Borrow Date</label>
                        <input type="datetime-local" class="form-control" id="edit_borrow_date" name="borrow_date" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" name="action" value="update" class="btn btn-primary">
                        <i class="bi bi-check-circle"></i> Update Record
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View Member Details Modal -->
<div class="modal fade" id="viewMemberModal" tabindex="-1" aria-labelledby="viewMemberModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewMemberModalLabel">
                    <i class="bi bi-person-circle"></i> Member Details
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="memberDetailsContent">
                    <!-- Content will be loaded here -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- View Book Details Modal -->
<div class="modal fade" id="viewBookModal" tabindex="-1" aria-labelledby="viewBookModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewBookModalLabel">
                    <i class="bi bi-book"></i> Book Details
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="bookDetailsContent">
                    <!-- Content will be loaded here -->
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteConfirmModal" tabindex="-1" aria-labelledby="deleteConfirmModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteConfirmModalLabel">
                    <i class="bi bi-exclamation-triangle text-danger"></i> Confirm Delete
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete this item? This action cannot be undone.</p>
                <div id="deleteItemInfo"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDeleteBtn">
                    <i class="bi bi-trash"></i> Delete
                </button>
            </div>
        </div>
    </div>
</div>

<script>
// JavaScript functions for modal operations

// Edit Member
function editMember(id, name, course, email) {
    document.getElementById('edit_member_id').value = id;
    document.getElementById('edit_name').value = name;
    document.getElementById('edit_course').value = course;
    document.getElementById('edit_email').value = email;
    
    const modal = new bootstrap.Modal(document.getElementById('editMemberModal'));
    modal.show();
}

// Edit Book
function editBook(id, title, author) {
    document.getElementById('edit_book_id').value = id;
    document.getElementById('edit_title').value = title;
    document.getElementById('edit_author').value = author;
    
    const modal = new bootstrap.Modal(document.getElementById('editBookModal'));
    modal.show();
}

// Edit Borrowed Book
function editBorrowed(id, memberId, bookId, borrowDate) {
    document.getElementById('edit_borrowed_id').value = id;
    document.getElementById('edit_borrowed_member_id').value = memberId;
    document.getElementById('edit_borrowed_book_id').value = bookId;
    document.getElementById('edit_borrow_date').value = borrowDate;
    
    const modal = new bootstrap.Modal(document.getElementById('editBorrowedModal'));
    modal.show();
}

// View Member Details
function viewMember(id) {
    fetch(`actions/member_actions.php?action=view&id=${id}`)
        .then(response => response.text())
        .then(data => {
            document.getElementById('memberDetailsContent').innerHTML = data;
            const modal = new bootstrap.Modal(document.getElementById('viewMemberModal'));
            modal.show();
        });
}

// View Book Details
function viewBook(id) {
    fetch(`actions/book_actions.php?action=view&id=${id}`)
        .then(response => response.text())
        .then(data => {
            document.getElementById('bookDetailsContent').innerHTML = data;
            const modal = new bootstrap.Modal(document.getElementById('viewBookModal'));
            modal.show();
        });
}

// Show Delete Confirmation
function showDeleteConfirm(type, id, name) {
    document.getElementById('deleteItemInfo').innerHTML = `
        <div class="alert alert-warning">
            <strong>${type.charAt(0).toUpperCase() + type.slice(1)}:</strong> ${name}
        </div>
    `;
    
    document.getElementById('confirmDeleteBtn').onclick = function() {
        // Redirect to delete action
        window.location.href = `actions/${type}_actions.php?action=delete&id=${id}`;
    };
    
    const modal = new bootstrap.Modal(document.getElementById('deleteConfirmModal'));
    modal.show();
}
</script>
