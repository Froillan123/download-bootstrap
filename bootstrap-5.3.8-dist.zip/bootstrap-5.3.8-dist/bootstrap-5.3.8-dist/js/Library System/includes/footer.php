    </div> <!-- End of main container -->

    <!-- Footer -->
    <footer class="bg-light text-center text-muted py-4 mt-5">
        <div class="container">
            <p class="mb-0">
                <i class="bi bi-book"></i> Library System &copy; <?php echo date('Y'); ?> | 
                <?php 
                require_once 'config/functions.php';
                echo getDatabaseInfo(); 
                ?>
            </p>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <!-- DataTables JS -->
    <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.13.7/js/dataTables.bootstrap5.min.js"></script>

    <script>
        // Initialize DataTables
        $(document).ready(function() {
            $('.datatable').DataTable({
                responsive: true,
                language: {
                    search: "Search:",
                    lengthMenu: "Show _MENU_ entries per page",
                    info: "Showing _START_ to _END_ of _TOTAL_ entries",
                    paginate: {
                        first: "First",
                        last: "Last",
                        next: "Next",
                        previous: "Previous"
                    }
                }
            });
        });

        // Alerts are now handled by the toast system

        // Confirm delete actions
        function confirmDelete(message = 'Are you sure you want to delete this item?') {
            return confirm(message);
        }

        // Delete confirmation is handled in modals.php

        // Show modal with data
        function showEditModal(modalId, data) {
            const modal = new bootstrap.Modal(document.getElementById(modalId));
            
            // Fill form fields with data
            Object.keys(data).forEach(key => {
                const field = document.querySelector(`#${modalId} [name="${key}"]`);
                if (field) {
                    field.value = data[key];
                }
            });
            
            modal.show();
        }

        // Reset form when modal is hidden
        document.addEventListener('DOMContentLoaded', function() {
            const modals = document.querySelectorAll('.modal');
            modals.forEach(modal => {
                modal.addEventListener('hidden.bs.modal', function() {
                    const form = this.querySelector('form');
                    if (form) {
                        form.reset();
                    }
                });
            });
        });

        // Search functionality for borrowed books
        function searchBorrowedBooks() {
            const searchTerm = document.getElementById('searchInput').value;
            const table = document.getElementById('borrowedBooksTable');
            const rows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
            
            for (let i = 0; i < rows.length; i++) {
                const row = rows[i];
                const text = row.textContent.toLowerCase();
                if (text.includes(searchTerm.toLowerCase())) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        }

        // Real-time search
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('searchInput');
            if (searchInput) {
                searchInput.addEventListener('input', searchBorrowedBooks);
            }
        });
        
        // Toast Notification System
        function showToast(message, type = 'info', title = null) {
            const toastContainer = document.getElementById('toastContainer');
            const toastId = 'toast_' + Date.now();
            
            // Set default title based on type
            if (!title) {
                switch(type) {
                    case 'success':
                        title = 'Success!';
                        break;
                    case 'danger':
                        title = 'Error!';
                        break;
                    case 'warning':
                        title = 'Warning!';
                        break;
                    case 'info':
                    default:
                        title = 'Information';
                        break;
                }
            }
            
            // Set icon based on type
            let icon = 'bi-info-circle';
            switch(type) {
                case 'success':
                    icon = 'bi-check-circle';
                    break;
                case 'danger':
                    icon = 'bi-exclamation-triangle';
                    break;
                case 'warning':
                    icon = 'bi-exclamation-triangle';
                    break;
                case 'info':
                    icon = 'bi-info-circle';
                    break;
            }
            
            const toast = document.createElement('div');
            toast.className = `toast ${type} show`;
            toast.id = toastId;
            toast.innerHTML = `
                <div class="toast-header">
                    <i class="bi ${icon} me-2"></i>
                    <strong class="me-auto">${title}</strong>
                    <button type="button" class="btn-close" onclick="removeToast('${toastId}')"></button>
                </div>
                <div class="toast-body">
                    ${message}
                </div>
            `;
            
            toastContainer.appendChild(toast);
            
            // Auto-remove after 5 seconds
            setTimeout(() => {
                removeToast(toastId);
            }, 5000);
        }
        
        function removeToast(toastId) {
            const toast = document.getElementById(toastId);
            if (toast) {
                toast.classList.add('hide');
                setTimeout(() => {
                    if (toast.parentNode) {
                        toast.parentNode.removeChild(toast);
                    }
                }, 300);
            }
        }
        
        // Check for session messages and show toasts
        document.addEventListener('DOMContentLoaded', function() {
            // Check if there are any session messages to display
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                // Extract message and type from alert
                const message = alert.textContent.trim();
                let type = 'info';
                
                if (alert.classList.contains('alert-success')) {
                    type = 'success';
                } else if (alert.classList.contains('alert-danger')) {
                    type = 'danger';
                } else if (alert.classList.contains('alert-warning')) {
                    type = 'warning';
                } else if (alert.classList.contains('alert-info')) {
                    type = 'info';
                }
                
                // Show toast
                showToast(message, type);
                
                // Remove the original alert
                alert.remove();
            });
            
            // Check for toast messages from PHP actions
            const toastMessage = document.getElementById('toastMessage');
            if (toastMessage) {
                const message = toastMessage.getAttribute('data-message');
                const type = toastMessage.getAttribute('data-type');
                
                if (message && type) {
                    // Show toast after a short delay to ensure everything is loaded
                    setTimeout(function() {
                        showToast(message, type);
                    }, 300);
                    
                    // Remove the hidden message element
                    toastMessage.remove();
                }
            }
        });
    </script>
</body>
</html>
