# 🛠️ Installation & Setup Guide

## 📋 Prerequisites

### System Requirements
- **Operating System**: Windows, macOS, or Linux
- **Web Server**: XAMPP (recommended) or any PHP-compatible server
- **PHP Version**: 7.4 or higher
- **Database**: MySQL (via XAMPP) or SQLite
- **Browser**: Modern web browser (Chrome, Firefox, Safari, Edge)

### Required Software
- **XAMPP**: For Apache and MySQL
- **PHP**: For running the application
- **Text Editor**: For editing configuration files

## 🚀 Installation Steps

### Step 1: Download and Extract

1. **Download Project**
   - Clone from Git repository, or
   - Download ZIP file and extract

2. **Extract to Web Directory**
   ```
   # For XAMPP (Windows)
   C:\xampp\htdocs\Library System\
   
   # For XAMPP (macOS)
   /Applications/XAMPP/htdocs/Library System/
   
   # For XAMPP (Linux)
   /opt/lampp/htdocs/Library System/
   ```

3. **Verify File Structure**
   ```
   Library System/
   ├── config/
   ├── database/
   ├── includes/
   ├── actions/
   ├── index.php
   ├── members.php
   ├── books.php
   ├── borrowed.php
   └── README.md
   ```

### Step 2: Start XAMPP Services

1. **Launch XAMPP Control Panel**
   - Windows: Run `xampp-control.exe`
   - macOS: Open XAMPP application
   - Linux: Run `sudo /opt/lampp/lampp start`

2. **Start Required Services**
   ```
   ✅ Apache - Start
   ✅ MySQL - Start
   ❌ FileZilla - Not needed
   ❌ Mercury - Not needed
   ❌ Tomcat - Not needed
   ```

3. **Verify Services**
   - Apache: Green status, port 80/443
   - MySQL: Green status, port 3306

### Step 3: Database Configuration

#### Option A: MySQL (Recommended for XAMPP)

1. **Create Database**
   - Open browser: `http://localhost/phpmyadmin`
   - Click "New" on left sidebar
   - Enter database name: `library_system`
   - Click "Create"

2. **Edit Configuration File**
   ```php
   // File: config/database.php
   define('DB_TYPE', 'mysql');  // Keep as 'mysql'
   ```

3. **Verify Connection**
   - Visit: `http://localhost/Library System/`
   - Tables will be created automatically

#### Option B: SQLite

1. **Create Database Directory**
   ```bash
   # In your project folder
   mkdir database
   ```

2. **Edit Configuration File**
   ```php
   // File: config/database.php
   define('DB_TYPE', 'sqlite');  // Change to 'sqlite'
   ```

3. **Set Permissions** (Linux/macOS)
   ```bash
   chmod 755 database/
   ```

### Step 4: Test Installation

1. **Access Application**
   - Open browser: `http://localhost/Library System/`
   - Should see dashboard with statistics

2. **Verify Features**
   - Dashboard loads without errors
   - Navigation menu works
   - Database type shows correctly

## ⚙️ Configuration Details

### Database Configuration File

**File**: `config/database.php`

#### MySQL Configuration
```php
define('DB_TYPE', 'mysql');
define('DB_HOST', 'localhost');
define('DB_NAME', 'library_system');
define('DB_USER', 'root');
define('DB_PASS', '');
```

#### SQLite Configuration
```php
define('DB_TYPE', 'sqlite');
define('DB_FILE', 'database/library.db');
```

### PHP Configuration

#### Required Extensions
```ini
; php.ini settings
extension=pdo
extension=pdo_mysql
extension=pdo_sqlite
extension=sqlite3
```

#### Recommended Settings
```ini
; Performance and security
display_errors = Off
log_errors = On
error_reporting = E_ALL
max_execution_time = 30
memory_limit = 128M
```

## 🔧 Advanced Configuration

### Custom Database Settings

#### Custom MySQL Host
```php
// For remote MySQL server
define('DB_HOST', '192.168.1.100');
define('DB_USER', 'library_user');
define('DB_PASS', 'secure_password');
```

#### Custom SQLite Path
```php
// Custom database location
define('DB_FILE', '/var/www/library_data/library.db');
```

### Web Server Configuration

#### Apache (.htaccess)
```apache
# Enable URL rewriting
RewriteEngine On

# Security headers
Header always set X-Content-Type-Options nosniff
Header always set X-Frame-Options DENY
Header always set X-XSS-Protection "1; mode=block"

# PHP settings
php_value upload_max_filesize 10M
php_value post_max_size 10M
```

#### Nginx Configuration
```nginx
server {
    listen 80;
    server_name library.local;
    root /var/www/Library System;
    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php7.4-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
        include fastcgi_params;
    }
}
```

## 🚨 Troubleshooting

### Common Installation Issues

#### 1. "Page Not Found" Error
**Problem**: Apache can't find the application
**Solution**:
```bash
# Check XAMPP is running
# Verify file path is correct
# Check Apache document root
```

#### 2. "Database Connection Failed"
**Problem**: Can't connect to database
**Solutions**:
```bash
# For MySQL:
# - Check MySQL service is running
# - Verify database exists
# - Check username/password

# For SQLite:
# - Check folder permissions
# - Verify database path
```

#### 3. "Permission Denied"
**Problem**: Web server can't write to database
**Solution**:
```bash
# Linux/macOS
chmod 755 database/
chmod 666 database/library.db

# Windows
# Right-click folder → Properties → Security → Edit permissions
```

#### 4. "Session Start Error"
**Problem**: `session_start()` called after output
**Solution**:
```php
// Remove from config/database.php
// session_start(); // Remove this line

// Add to each main page (index.php, members.php, etc.)
<?php
session_start(); // Add this line at the very top
$pageTitle = "Page Title";
// ... rest of code
```

### Performance Issues

#### 1. Slow Page Loading
**Solutions**:
```php
// Enable PHP OPcache
opcache.enable=1
opcache.memory_consumption=128

// Use database indexes
CREATE INDEX idx_member_name ON members(name);
CREATE INDEX idx_book_title ON books(title);
```

#### 2. High Memory Usage
**Solutions**:
```php
// Limit database results
SELECT * FROM borrowed_books LIMIT 100;

// Use pagination
$page = $_GET['page'] ?? 1;
$limit = 50;
$offset = ($page - 1) * $limit;
```

### Security Issues

#### 1. SQL Injection Vulnerabilities
**Problem**: User input not properly sanitized
**Solution**: Already implemented with prepared statements

#### 2. XSS Vulnerabilities
**Problem**: Output not properly escaped
**Solution**: Already implemented with `htmlspecialchars()`

#### 3. File Upload Vulnerabilities
**Problem**: Unrestricted file uploads
**Solution**: No file uploads in this system

## 📊 Testing Your Installation

### Basic Functionality Test

1. **Dashboard Test**
   - [ ] Page loads without errors
   - [ ] Statistics cards display correctly
   - [ ] Quick action buttons work

2. **Navigation Test**
   - [ ] All menu items work
   - [ ] Active page is highlighted
   - [ ] Responsive menu works on mobile

3. **Database Test**
   - [ ] Tables created automatically
   - [ ] Can add test data
   - [ ] Data persists between page loads

### Advanced Functionality Test

1. **CRUD Operations**
   - [ ] Add new member
   - [ ] Edit existing member
   - [ ] Delete member (when eligible)
   - [ ] Add new book
   - [ ] Edit existing book
   - [ ] Delete book (when eligible)

2. **Borrowing System**
   - [ ] Borrow book for member
   - [ ] View borrowed books
   - [ ] Return book
   - [ ] Search borrowed books

3. **Search and Filter**
   - [ ] Search works in all tables
   - [ ] Filters work correctly
   - [ ] Export functions work

## 🔄 Maintenance and Updates

### Regular Maintenance

#### Daily Tasks
- [ ] Check system is running
- [ ] Monitor error logs
- [ ] Verify database connectivity

#### Weekly Tasks
- [ ] Backup database
- [ ] Check system performance
- [ ] Review error logs

#### Monthly Tasks
- [ ] Update system if needed
- [ ] Review security settings
- [ ] Performance optimization

### Backup Procedures

#### MySQL Backup
```bash
# Using mysqldump
mysqldump -u root -p library_system > backup_$(date +%Y%m%d).sql

# Using phpMyAdmin
# Export → Custom → SQL → Go
```

#### SQLite Backup
```bash
# Simple file copy
cp database/library.db backup/library_$(date +%Y%m%d).db

# Using SQLite command
sqlite3 database/library.db ".backup backup/library_backup.db"
```

### Update Procedures

1. **Backup Current System**
   - Database backup
   - File backup

2. **Download New Version**
   - Extract to temporary location
   - Review changes

3. **Update Files**
   - Replace old files with new ones
   - Keep configuration files

4. **Test System**
   - Verify all functionality works
   - Check database integrity

## 📞 Getting Help

### Self-Help Resources
1. **Check this documentation**
2. **Review error logs**
3. **Test with sample data**
4. **Verify configuration**

### Common Error Messages
- **"Connection failed"**: Database service not running
- **"Permission denied"**: File/folder permission issues
- **"Table doesn't exist"**: Database not initialized
- **"Session start error"**: Output before session_start()

### Support Channels
1. **Documentation**: README.md and specialized guides
2. **Error Logs**: Check Apache and PHP error logs
3. **Community**: PHP and database forums
4. **Professional**: Hire developer for complex issues

---

**Previous: [USAGE.md](USAGE.md) - System Usage Guide**  
**Back to: [README.md](README.md) - Main Documentation**
