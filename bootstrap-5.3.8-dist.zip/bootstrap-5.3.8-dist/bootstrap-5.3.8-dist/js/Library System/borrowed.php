<?php
$pageTitle = "Borrowed Books";
require_once 'includes/header.php';
require_once 'config/functions.php';

$borrowedBooks = getAllBorrowedBooks();
?>

<div class="row">
    <div class="col-12">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0">
                <i class="bi bi-arrow-left-right"></i> Borrowed Books Management
            </h1>
            <button class="btn btn-info" data-bs-toggle="modal" data-bs-target="#borrowBookModal">
                <i class="bi bi-plus-circle"></i> Borrow a Book
            </button>
        </div>
    </div>
</div>

<!-- Search and Filter -->
<div class="card mb-4">
    <div class="card-header">
        <h6 class="mb-0">
            <i class="bi bi-search"></i> Search & Filter
        </h6>
    </div>
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <div class="input-group">
                    <span class="input-group-text">
                        <i class="bi bi-search"></i>
                    </span>
                    <input type="text" class="form-control" id="searchInput" placeholder="Search by member name, book title, or author...">
                </div>
            </div>
            <div class="col-md-3">
                <select class="form-select" id="statusFilter">
                    <option value="">All Status</option>
                    <option value="recent">Recent (Last 7 days)</option>
                    <option value="old">Older than 30 days</option>
                </select>
            </div>
            <div class="col-md-3">
                <button class="btn btn-outline-secondary w-100" onclick="clearFilters()">
                    <i class="bi bi-arrow-clockwise"></i> Clear Filters
                </button>
            </div>
        </div>
    </div>
</div>

<!-- Borrowed Books Table -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="bi bi-list-ul"></i> All Borrowed Books
        </h5>
    </div>
    <div class="card-body">
        <?php if (empty($borrowedBooks)): ?>
            <div class="text-center py-5">
                <i class="bi bi-arrow-left-right display-1 text-muted"></i>
                <h4 class="text-muted mt-3">No Borrowed Books Found</h4>
                <p class="text-muted">Start by borrowing a book using the button above.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="table table-hover" id="borrowedBooksTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Member</th>
                            <th>Book</th>
                            <th>Borrow Date</th>
                            <th>Duration</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($borrowedBooks as $borrowed): ?>
                            <?php
                            $borrowDate = new DateTime($borrowed['borrow_date']);
                            $now = new DateTime();
                            $duration = $borrowDate->diff($now);
                            $daysDiff = $duration->days;
                            $statusClass = $daysDiff > 30 ? 'text-danger' : ($daysDiff > 7 ? 'text-warning' : 'text-success');
                            ?>
                            <tr>
                                <td>
                                    <span class="badge bg-secondary"><?php echo $borrowed['id']; ?></span>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0">
                                            <i class="bi bi-person-circle text-primary"></i>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <strong><?php echo htmlspecialchars($borrowed['member_name']); ?></strong><br>
                                            <small class="text-muted"><?php echo htmlspecialchars($borrowed['course']); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="flex-shrink-0">
                                            <i class="bi bi-book text-info"></i>
                                        </div>
                                        <div class="flex-grow-1 ms-3">
                                            <strong><?php echo htmlspecialchars($borrowed['title']); ?></strong><br>
                                            <small class="text-muted">by <?php echo htmlspecialchars($borrowed['author']); ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="<?php echo $statusClass; ?>">
                                        <?php echo formatDate($borrowed['borrow_date']); ?>
                                    </div>
                                </td>
                                <td>
                                    <span class="badge <?php echo $daysDiff > 30 ? 'bg-danger' : ($daysDiff > 7 ? 'bg-warning' : 'bg-success'); ?>">
                                        <?php echo $daysDiff; ?> day<?php echo $daysDiff != 1 ? 's' : ''; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <button type="button" class="btn btn-sm btn-outline-primary" 
                                                onclick="editBorrowed(<?php echo $borrowed['id']; ?>, <?php echo $borrowed['member_id']; ?>, <?php echo $borrowed['book_id']; ?>, '<?php echo $borrowed['borrow_date']; ?>')">
                                            <i class="bi bi-pencil"></i>
                                        </button>
                                        <button type="button" class="btn btn-sm btn-outline-danger" 
                                                onclick="showDeleteConfirm('borrowed', <?php echo $borrowed['id']; ?>, 'Borrowed book: <?php echo htmlspecialchars($borrowed['title']); ?>')">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Statistics and Analysis -->
<div class="row mt-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="bi bi-graph-up"></i> Borrowing Statistics
                </h6>
            </div>
            <div class="card-body">
                <?php
                $recentBorrows = array_filter($borrowedBooks, function($b) {
                    $borrowDate = new DateTime($b['borrow_date']);
                    $now = new DateTime();
                    $diff = $borrowDate->diff($now);
                    return $diff->days <= 7;
                });
                
                $oldBorrows = array_filter($borrowedBooks, function($b) {
                    $borrowDate = new DateTime($b['borrow_date']);
                    $now = new DateTime();
                    $diff = $borrowDate->diff($now);
                    return $diff->days > 30;
                });
                ?>
                <div class="row text-center">
                    <div class="col-4">
                        <h5 class="text-success"><?php echo count($recentBorrows); ?></h5>
                        <small class="text-muted">Recent (≤7 days)</small>
                    </div>
                    <div class="col-4">
                        <h5 class="text-warning"><?php echo count($borrowedBooks) - count($recentBorrows) - count($oldBorrows); ?></h5>
                        <small class="text-muted">Medium (8-30 days)</small>
                    </div>
                    <div class="col-4">
                        <h5 class="text-danger"><?php echo count($oldBorrows); ?></h5>
                        <small class="text-muted">Overdue (>30 days)</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h6 class="mb-0">
                    <i class="bi bi-clock-history"></i> Recent Activity
                </h6>
            </div>
            <div class="card-body">
                <?php
                $recentActivity = array_slice($borrowedBooks, 0, 3);
                foreach ($recentActivity as $activity) {
                    echo '<div class="d-flex align-items-center mb-2">';
                    echo '<div class="flex-shrink-0">';
                    echo '<i class="bi bi-arrow-left-right text-info"></i>';
                    echo '</div>';
                    echo '<div class="flex-grow-1 ms-3">';
                    echo '<strong>' . htmlspecialchars($activity['member_name']) . '</strong> borrowed ';
                    echo '<strong>' . htmlspecialchars($activity['title']) . '</strong>';
                    echo '</div>';
                    echo '<small class="text-muted">' . formatDate($activity['borrow_date']) . '</small>';
                    echo '</div>';
                }
                ?>
            </div>
        </div>
    </div>
</div>

<script>
// Additional JavaScript for borrowed books page
function clearFilters() {
    document.getElementById('searchInput').value = '';
    document.getElementById('statusFilter').value = '';
    searchBorrowedBooks();
}

// Enhanced search with status filter
function searchBorrowedBooks() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const statusFilter = document.getElementById('statusFilter').value;
    const table = document.getElementById('borrowedBooksTable');
    const rows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
    
    for (let i = 0; i < rows.length; i++) {
        const row = rows[i];
        const text = row.textContent.toLowerCase();
        const borrowDateCell = row.cells[3]; // Borrow date column
        const borrowDate = new Date(borrowDateCell.textContent);
        const now = new Date();
        const daysDiff = Math.floor((now - borrowDate) / (1000 * 60 * 60 * 24));
        
        let showBySearch = text.includes(searchTerm);
        let showByStatus = true;
        
        if (statusFilter === 'recent') {
            showByStatus = daysDiff <= 7;
        } else if (statusFilter === 'old') {
            showByStatus = daysDiff > 30;
        }
        
        if (showBySearch && showByStatus) {
            row.style.display = '';
        } else {
            row.style.display = 'none';
        }
    }
}

// Add event listeners
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    const statusFilter = document.getElementById('statusFilter');
    
    if (searchInput) {
        searchInput.addEventListener('input', searchBorrowedBooks);
    }
    
    if (statusFilter) {
        statusFilter.addEventListener('change', searchBorrowedBooks);
    }
});
</script>

<?php require_once 'includes/modals.php'; ?>
<?php require_once 'includes/footer.php'; ?>
